# Fiscal_API

API for Custom Fiscal Devices (RUS)