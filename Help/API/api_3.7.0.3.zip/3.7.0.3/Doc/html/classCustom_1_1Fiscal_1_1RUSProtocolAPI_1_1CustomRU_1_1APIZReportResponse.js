var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIZReportResponse =
[
    [ "APIZReportResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIZReportResponse.html#a7a32f2c3bf10bde7e1cf341434f7209d", null ],
    [ "APIZReportResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIZReportResponse.html#a4ec8ec85dc0aac026808db2ef992a1ad", null ],
    [ "CashierName", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIZReportResponse.html#a1792bd3cca0cb99b7eefc8c5c056ee83", null ],
    [ "DocumentNumber", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIZReportResponse.html#a623b1d98036a25f85e7374af5fb73f93", null ],
    [ "FiscalSignature", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIZReportResponse.html#a89129c34c974b015a3d8eb377027560c", null ],
    [ "SessionNumber", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIZReportResponse.html#a00b3f3c613edd130c1407709578d6447", null ]
];