var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIDepartment =
[
    [ "DepartmentGroup", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIDepartment.html#a725c0a2e6ef1052046c7c518589cac99", null ],
    [ "DepartmentOperatorType", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIDepartment.html#a236574d17c871d0a87fa90291388b6a9", null ],
    [ "Description", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIDepartment.html#a7b3027c8efb3686f62e10b9631815bd9", null ],
    [ "DiscMarkupMode", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIDepartment.html#ae95f68444e670dc6de405c857f4fd83c", null ],
    [ "DiscMarkupOperatorType", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIDepartment.html#a7014182ccd1d1cbe93f838dffca7441c", null ],
    [ "Macro", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIDepartment.html#a09661ab21c1231bc994a1d9c4bdece5e", null ],
    [ "MaxAmount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIDepartment.html#aba098f41868316809af37a8288dd1af3", null ],
    [ "MinAmount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIDepartment.html#abc9f9111116bd84e80f7f007302e46ff", null ],
    [ "Price", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIDepartment.html#ade16dbe1c211e9575af82f0dbadfd82f", null ],
    [ "Price1", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIDepartment.html#a4ccf89caab6b2de8b8a380f516dfbd0b", null ],
    [ "SingleItemReceipt", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIDepartment.html#a8b439357e03699918e5bdbb14dadf31b", null ],
    [ "VatCode", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIDepartment.html#a2195d25b96cba7e463f55417baf90e95", null ],
    [ "VoidOperatorType", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIDepartment.html#a385647fd0f8652f1d59b6ab92a9f6f02", null ],
    [ "WriteOffsOperatorType", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIDepartment.html#acfa19f22cd5690ccbe4acf69338f2697", null ]
];