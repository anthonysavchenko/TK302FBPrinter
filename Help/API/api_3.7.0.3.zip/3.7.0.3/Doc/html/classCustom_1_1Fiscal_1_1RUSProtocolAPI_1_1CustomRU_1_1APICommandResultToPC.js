var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APICommandResultToPC =
[
    [ "APICommandResultToPC", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APICommandResultToPC.html#ac05f0a71e96e045f5c58e27a4720329e", null ],
    [ "APICommandResultToPC", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APICommandResultToPC.html#a72b6c0cdd2e1b0b11de317fdbf0a5ea7", null ],
    [ "Value", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APICommandResultToPC.html#aa9547f29ce0c56ec07ac054ad7f4ae08", null ]
];