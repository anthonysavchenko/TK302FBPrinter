var namespaceCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1Comunication =
[
    [ "PortStatusEventArgs", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1Comunication_1_1PortStatusEventArgs.html", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1Comunication_1_1PortStatusEventArgs" ]
];