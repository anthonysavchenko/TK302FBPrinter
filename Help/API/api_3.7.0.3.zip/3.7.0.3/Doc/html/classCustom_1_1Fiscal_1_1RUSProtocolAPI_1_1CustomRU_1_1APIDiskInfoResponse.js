var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIDiskInfoResponse =
[
    [ "APIDiskInfoResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIDiskInfoResponse.html#ac73e6456921ab30934bcd57441e36741", null ],
    [ "APIDiskInfoResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIDiskInfoResponse.html#a818eaeeb99792332dbd06f028f7e3924", null ],
    [ "BytesPerSectors", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIDiskInfoResponse.html#a142dd74ba9244b0c0bcbb49099383839", null ],
    [ "FileSystemType", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIDiskInfoResponse.html#abb0209085dcd1faeb0cb65da5120f302", null ],
    [ "FreeClusters", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIDiskInfoResponse.html#a75160541b2a7636b7d7334055e84c661", null ],
    [ "OperatorNumber", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIDiskInfoResponse.html#af0d206feb8b74b058f3da9a5db57c67f", null ],
    [ "RootDirectories", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIDiskInfoResponse.html#a90a94817a7d31921724cce0d537dbcfc", null ],
    [ "SectorPerClusters", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIDiskInfoResponse.html#a18a8d777750ee9686186d10c7753b757", null ],
    [ "TotalClusters", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIDiskInfoResponse.html#ac773a721228024f02c16be2b118e4121", null ]
];