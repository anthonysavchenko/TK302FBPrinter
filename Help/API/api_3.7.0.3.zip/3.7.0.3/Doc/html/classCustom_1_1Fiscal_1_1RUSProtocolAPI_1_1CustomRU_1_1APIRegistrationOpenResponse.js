var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIRegistrationOpenResponse =
[
    [ "APIRegistrationOpenResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIRegistrationOpenResponse.html#aa88806d5535d0adff6d2367d0fd9dbbc", null ],
    [ "APIRegistrationOpenResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIRegistrationOpenResponse.html#ac8aa33e9be8a3dca4155483911586ebf", null ],
    [ "DocumentNumber", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIRegistrationOpenResponse.html#ab1968efba4781949e485a042832b3684", null ],
    [ "FiscalSignature", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIRegistrationOpenResponse.html#afd05b18a9a85c90bc917c6943fc42e78", null ]
];