var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APISubtotalModifierResponse =
[
    [ "APISubtotalModifierResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APISubtotalModifierResponse.html#a670700f2f8c49071fe3a162370d35dc8", null ],
    [ "APISubtotalModifierResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APISubtotalModifierResponse.html#ab16a5f5441469d7f1528f1a9f291d7ab", null ],
    [ "CurrentAddOnAmount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APISubtotalModifierResponse.html#a4bbb13947069464d398e81b724ac3e02", null ],
    [ "CurrentDiscountAmount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APISubtotalModifierResponse.html#aaee0058f44a9086ddbb8abd7f0dcaafe", null ],
    [ "DocumentNumber", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APISubtotalModifierResponse.html#a79b67b5304ee912e02353f94a42b7aab", null ],
    [ "SessionNumber", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APISubtotalModifierResponse.html#ae1086d9dabd6681f26836eccd3bc83bb", null ],
    [ "SubtotalAmount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APISubtotalModifierResponse.html#a12158ec246b1f1383bf6998aa3385156", null ]
];