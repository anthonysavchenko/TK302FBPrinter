var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIFMStatusResponse =
[
    [ "APIFMStatusResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIFMStatusResponse.html#a700833af8e6e4a387ba5f25cc3fd70ab", null ],
    [ "APIFMStatusResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIFMStatusResponse.html#a87c083674d420c1ed4b163963925b227", null ],
    [ "FMDateTime", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIFMStatusResponse.html#ae81bc09158d110113a810b19f478337c", null ],
    [ "FMDocumentData", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIFMStatusResponse.html#a1820a85eb82ebb73240609b505f5f5e8", null ],
    [ "FMFlagsandWarnings", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIFMStatusResponse.html#abc53e1a492ed194ec6a6a18505622f5a", null ],
    [ "FMLastDocumentNumber", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIFMStatusResponse.html#afbf213dbcbc39b63cb936a1a18c7c235", null ],
    [ "FMNumber", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIFMStatusResponse.html#ad764ef948e254342b2e67d521517fed8", null ],
    [ "FMRecentDocument", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIFMStatusResponse.html#aef3fc2f24ecb0587130d8e632eea4848", null ],
    [ "FMShiftStatus", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIFMStatusResponse.html#a6d2187c11a93a96ae3cfd1b3983de6c4", null ],
    [ "FMStateOfLife", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIFMStatusResponse.html#ac961425ca52d79420f0e4e8e418268ff", null ]
];