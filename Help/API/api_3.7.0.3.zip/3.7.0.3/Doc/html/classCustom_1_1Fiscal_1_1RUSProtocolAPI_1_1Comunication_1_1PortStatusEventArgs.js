var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1Comunication_1_1PortStatusEventArgs =
[
    [ "StatusType", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1Comunication_1_1PortStatusEventArgs.html#a590ee4eeb2f27e5169203843d5eb426c", [
      [ "Closed", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1Comunication_1_1PortStatusEventArgs.html#a590ee4eeb2f27e5169203843d5eb426ca03f4a47830f97377a35321051685071e", null ],
      [ "Opened", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1Comunication_1_1PortStatusEventArgs.html#a590ee4eeb2f27e5169203843d5eb426ca1a11b1adc359c03db0ca798a00e2632c", null ]
    ] ],
    [ "PortStatusEventArgs", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1Comunication_1_1PortStatusEventArgs.html#addbddb577cd40cefa805e0e445293072", null ],
    [ "Status", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1Comunication_1_1PortStatusEventArgs.html#ae977444106da2d1c63fa9381c6db0126", null ]
];