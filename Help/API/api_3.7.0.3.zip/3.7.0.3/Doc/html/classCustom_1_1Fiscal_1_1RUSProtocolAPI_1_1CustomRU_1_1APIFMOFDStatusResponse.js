var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIFMOFDStatusResponse =
[
    [ "APIFMOFDStatusResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIFMOFDStatusResponse.html#a1bb3c2c853598bab2e2a77cff64542ac", null ],
    [ "APIFMOFDStatusResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIFMOFDStatusResponse.html#aad67759e671cec3017d6a20c4f126f99", null ],
    [ "FMDataExchangeStatus", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIFMOFDStatusResponse.html#a1cdd47783dee469acae876f8aeb47245", null ],
    [ "FMFirstFDDateToTransmition", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIFMOFDStatusResponse.html#a58643968685a90120c86526c7fceb073", null ],
    [ "FMFirstFDNumberToTransmition", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIFMOFDStatusResponse.html#a9620d4c880826d27fd318b6661f5284e", null ],
    [ "FMQuantityForTramsmition", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIFMOFDStatusResponse.html#a03238f21c44897a5a0a9c3b2066ab2fb", null ],
    [ "FMStateOfExchange", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIFMOFDStatusResponse.html#a97e7b0a14c8f99f68ffc7ebcf072c8bd", null ]
];