var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIShiftStatusResponse =
[
    [ "APIShiftStatusResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIShiftStatusResponse.html#ad0b81368e04a5275c6cd8a3621d4a7e3", null ],
    [ "APIShiftStatusResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIShiftStatusResponse.html#a2f94c0d270d537dc673620a76b4dbac6", null ],
    [ "ExpireDate", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIShiftStatusResponse.html#ad65d1e82c281deea4fe883f843b800f8", null ],
    [ "Number", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIShiftStatusResponse.html#a76c9138631fdd732b93580af592ea87b", null ],
    [ "Status", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIShiftStatusResponse.html#a60656d778f2fb0e1b7534d0d13c1e336", null ]
];