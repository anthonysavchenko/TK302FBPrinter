var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1AppConfig_1_1APIConfiguration =
[
    [ "APIConfiguration", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1AppConfig_1_1APIConfiguration.html#ad7993119ccd3cdd13cbae3eb7e96e071", null ],
    [ "GetAppSetting", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1AppConfig_1_1APIConfiguration.html#a606c3105cdf0f26a8ea7ef0d1850e22f", null ],
    [ "Configuration", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1AppConfig_1_1APIConfiguration.html#ac47846e6ca8d3c805b7b82dbda8e36e2", null ]
];