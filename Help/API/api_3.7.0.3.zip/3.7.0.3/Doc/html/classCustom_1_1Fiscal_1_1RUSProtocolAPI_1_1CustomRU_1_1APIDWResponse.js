var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIDWResponse =
[
    [ "APIDWResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIDWResponse.html#aac9476a599c8e12175f5451b72499ebf", null ],
    [ "APIDWResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIDWResponse.html#a31dc697f89234b6feeec852d6f9352e7", null ],
    [ "CashInDrawer", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIDWResponse.html#a2c36fe5a678a6a02f9343bd918d4a25a", null ],
    [ "ThroughDocumentNumber", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIDWResponse.html#a3173ec4cabc3a151cb652d48871400d0", null ]
];