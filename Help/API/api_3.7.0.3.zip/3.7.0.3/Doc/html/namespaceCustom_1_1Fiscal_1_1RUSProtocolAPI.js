var namespaceCustom_1_1Fiscal_1_1RUSProtocolAPI =
[
    [ "AppConfig", "namespaceCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1AppConfig.html", "namespaceCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1AppConfig" ],
    [ "Comunication", "namespaceCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1Comunication.html", "namespaceCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1Comunication" ],
    [ "Custom", "namespaceCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1Custom.html", "namespaceCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1Custom" ],
    [ "CustomRU", "namespaceCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU.html", "namespaceCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU" ],
    [ "Log", "namespaceCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1Log.html", "namespaceCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1Log" ],
    [ "OperationResult", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1OperationResult.html", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1OperationResult" ],
    [ "PortStatusEventArgs", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1PortStatusEventArgs.html", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1PortStatusEventArgs" ],
    [ "ProtocolAPI", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1ProtocolAPI.html", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1ProtocolAPI" ],
    [ "RUSProtocolException", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1RUSProtocolException.html", null ]
];