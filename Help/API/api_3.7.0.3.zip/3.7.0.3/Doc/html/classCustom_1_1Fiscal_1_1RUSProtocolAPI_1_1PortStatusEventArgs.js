var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1PortStatusEventArgs =
[
    [ "StatusType", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1PortStatusEventArgs.html#a0fc60a41f8d720484254dfad35713b54", [
      [ "Closed", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1PortStatusEventArgs.html#a0fc60a41f8d720484254dfad35713b54a03f4a47830f97377a35321051685071e", null ],
      [ "Opened", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1PortStatusEventArgs.html#a0fc60a41f8d720484254dfad35713b54a1a11b1adc359c03db0ca798a00e2632c", null ]
    ] ],
    [ "PortStatusEventArgs", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1PortStatusEventArgs.html#a0302dd67d7442b62dacaf139065f642d", null ],
    [ "Status", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1PortStatusEventArgs.html#ab1a16fc00b740abd45e2a58eaac4e350", null ]
];