var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIFileReadResponse =
[
    [ "APIFileReadResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIFileReadResponse.html#a79f051cd69fbfd10aaceef7b21045ff4", null ],
    [ "APIFileReadResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIFileReadResponse.html#ab30b0815253b4d09af9d67d9235d7053", null ],
    [ "Value", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIFileReadResponse.html#a55931eed7bd889cfa5bff293a7bc1a4d", null ]
];