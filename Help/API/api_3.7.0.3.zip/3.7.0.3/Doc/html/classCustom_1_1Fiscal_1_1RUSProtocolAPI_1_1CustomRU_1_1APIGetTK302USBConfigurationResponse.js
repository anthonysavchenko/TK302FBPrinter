var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetTK302USBConfigurationResponse =
[
    [ "APIGetTK302USBConfigurationResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetTK302USBConfigurationResponse.html#a8335c93885f4ee0a885ab32322ebf87e", null ],
    [ "APIGetTK302USBConfigurationResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetTK302USBConfigurationResponse.html#a722127a55a8fe4be9fd94b0468b73c13", null ],
    [ "UsbAddress", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetTK302USBConfigurationResponse.html#a4c643f1132bfc88550905b94587d9ba9", null ],
    [ "UsbClass", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetTK302USBConfigurationResponse.html#a92420769267b3363e5f4860870a6ca9c", null ]
];