var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetTK302PaperConfigurationResponse =
[
    [ "APIGetTK302PaperConfigurationResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetTK302PaperConfigurationResponse.html#ab6492015ade9592dd1fee7a5e21fd3c8", null ],
    [ "APIGetTK302PaperConfigurationResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetTK302PaperConfigurationResponse.html#a4d8067f824302e99cbe6ebd83a47292e", null ],
    [ "CharsInch", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetTK302PaperConfigurationResponse.html#aeeee04ccf23ee968ff5656b1f8f4a5f8", null ],
    [ "CutterEnabled", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetTK302PaperConfigurationResponse.html#a0816f1456815c94b8dc7e232c8c3e517", null ],
    [ "PaperWidth", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetTK302PaperConfigurationResponse.html#a14cea20146bd52b8c01b83bb32957ce9", null ],
    [ "PrintDensity", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetTK302PaperConfigurationResponse.html#aa5625fca9e9bb5fb67dae05605484c13", null ],
    [ "Speed", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetTK302PaperConfigurationResponse.html#a085a73581ebd730adc3a79f300f64b51", null ]
];