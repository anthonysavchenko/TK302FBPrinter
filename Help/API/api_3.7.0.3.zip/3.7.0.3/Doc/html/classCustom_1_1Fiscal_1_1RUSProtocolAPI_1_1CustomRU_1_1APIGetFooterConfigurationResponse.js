var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetFooterConfigurationResponse =
[
    [ "APIGetFooterConfigurationResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetFooterConfigurationResponse.html#a9c6c62212fbda583da632c028fc9e4ba", null ],
    [ "APIGetFooterConfigurationResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetFooterConfigurationResponse.html#a10e9fd77fabaca8e6f3c50ca2a71c753", null ],
    [ "Rows", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetFooterConfigurationResponse.html#ad9e1ab30977281470810db2da8b3015b", null ]
];