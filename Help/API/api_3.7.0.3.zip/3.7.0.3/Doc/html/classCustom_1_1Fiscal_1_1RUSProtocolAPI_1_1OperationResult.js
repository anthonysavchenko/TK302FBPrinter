var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1OperationResult =
[
    [ "Message", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1OperationResult.html#a9d1430ee713e42cb47cb12c315fcfe24", null ],
    [ "OperationIsOK", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1OperationResult.html#a8b9bed6eb8d69e03adb017e05899f95d", null ]
];