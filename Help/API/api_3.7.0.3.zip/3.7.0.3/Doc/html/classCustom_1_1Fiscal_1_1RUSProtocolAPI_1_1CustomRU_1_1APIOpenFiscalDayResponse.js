var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIOpenFiscalDayResponse =
[
    [ "APIOpenFiscalDayResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIOpenFiscalDayResponse.html#a0da626ca6481e2b80ff4a688aa43080e", null ],
    [ "APIOpenFiscalDayResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIOpenFiscalDayResponse.html#a0c2fd98ba83cd95bb6eff2b2a99f4f75", null ],
    [ "CashierName", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIOpenFiscalDayResponse.html#a5bd8618ea99a15f9ef74038878a8238c", null ],
    [ "DocumentNumber", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIOpenFiscalDayResponse.html#a44ed1d7932cbd9cd2985ca020c6b93d3", null ],
    [ "FiscalSignature", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIOpenFiscalDayResponse.html#a3ab17dd70c3ac341f21c89c509085613", null ],
    [ "SessionNumber", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIOpenFiscalDayResponse.html#ab41f515cf9c5f2336ebd2b8458047e79", null ]
];