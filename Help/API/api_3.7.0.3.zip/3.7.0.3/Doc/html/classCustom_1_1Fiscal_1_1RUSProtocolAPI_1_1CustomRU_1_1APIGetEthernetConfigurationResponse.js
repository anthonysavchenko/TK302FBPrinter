var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetEthernetConfigurationResponse =
[
    [ "APIGetEthernetConfigurationResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetEthernetConfigurationResponse.html#ae1558bc88fa7b72cca1456b552013fef", null ],
    [ "APIGetEthernetConfigurationResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetEthernetConfigurationResponse.html#afd537d814a5d9d6188aae370d4ad03e9", null ],
    [ "DHCPEnabled", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetEthernetConfigurationResponse.html#a36d088c5bb4a54854e9a38f7a97c8b55", null ],
    [ "DNS", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetEthernetConfigurationResponse.html#a5e4da209f3dc81eb71eeae0ef89a94da", null ],
    [ "Gateway", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetEthernetConfigurationResponse.html#a32d0e02ce9513444ce7b873bb0707375", null ],
    [ "IPAddress", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetEthernetConfigurationResponse.html#a220537a6a77846e062dc71b645ba21a0", null ],
    [ "MACAddress", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetEthernetConfigurationResponse.html#ae2223fb433058f4e92d7bcd810fbf98c", null ],
    [ "NetMask", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetEthernetConfigurationResponse.html#aacf102a8b86035afc31d7a95c873cf61", null ],
    [ "Port", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetEthernetConfigurationResponse.html#aa2541f64c0903d7aa7594efe54735c62", null ]
];