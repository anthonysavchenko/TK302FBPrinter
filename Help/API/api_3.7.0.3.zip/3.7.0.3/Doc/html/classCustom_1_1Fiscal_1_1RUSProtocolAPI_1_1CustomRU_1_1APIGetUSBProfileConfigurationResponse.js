var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetUSBProfileConfigurationResponse =
[
    [ "APIGetUSBProfileConfigurationResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetUSBProfileConfigurationResponse.html#a72637b57fde7afb9bdb5d9c7c0c7e885", null ],
    [ "APIGetUSBProfileConfigurationResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetUSBProfileConfigurationResponse.html#a91d843c691209548d892c179d99a2339", null ],
    [ "Profile", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetUSBProfileConfigurationResponse.html#a5f32dd9e4ab5f34cc8e8c86b0d782a0e", null ]
];