var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APICheckClosingResponse =
[
    [ "APICheckClosingResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APICheckClosingResponse.html#a1ea8969fb9d6ea7a39cbe597f22bc225", null ],
    [ "APICheckClosingResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APICheckClosingResponse.html#a9dd36d0c6d2b0b1a4640699a18fd2a53", null ],
    [ "CashierName", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APICheckClosingResponse.html#a86a2fa530c4e23a17c513d6ce6457883", null ],
    [ "ChangeAmount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APICheckClosingResponse.html#ac031454bfc9c3f02e51ea7ce9cdb962c", null ],
    [ "CheckNumber", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APICheckClosingResponse.html#a342cd3032b7c5cb8e0c10929aed34c4d", null ],
    [ "DocumentNumber", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APICheckClosingResponse.html#a80ab3d1bc63e191eff3a2b4e23deb1b5", null ],
    [ "FiscalSignature", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APICheckClosingResponse.html#a9c7f7e6ce98a85e6ee1e2d807104c42f", null ],
    [ "SessionNumber", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APICheckClosingResponse.html#af4426c6f05adef5c12d4bc9491cb5a64", null ]
];