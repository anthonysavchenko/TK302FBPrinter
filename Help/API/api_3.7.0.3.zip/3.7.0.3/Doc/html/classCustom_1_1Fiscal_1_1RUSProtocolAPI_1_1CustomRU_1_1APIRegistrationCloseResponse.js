var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIRegistrationCloseResponse =
[
    [ "APIRegistrationCloseResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIRegistrationCloseResponse.html#a646a66daaeafe26d2c28fbb6d81f3b6d", null ],
    [ "APIRegistrationCloseResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIRegistrationCloseResponse.html#ad889f7c021b03d77f1a64485a20d9050", null ],
    [ "CashierName", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIRegistrationCloseResponse.html#a486ac3160b3d37a75c47113421961fdb", null ],
    [ "DocumentNumber", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIRegistrationCloseResponse.html#ace584ad39626329814d6ab65ff363cac", null ],
    [ "FiscalSignature", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIRegistrationCloseResponse.html#a8ebb8839275a7081fa2ec3ba93a4c5b0", null ],
    [ "SessionNumber", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIRegistrationCloseResponse.html#ad4a93433a71c7f99480c296dd9aa7dd4", null ]
];