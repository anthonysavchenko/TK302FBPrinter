var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetOperatorTableRowResponse =
[
    [ "APIGetOperatorTableRowResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetOperatorTableRowResponse.html#a9f4c25ad8d90296cb9fd2c38e1455407", null ],
    [ "APIGetOperatorTableRowResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetOperatorTableRowResponse.html#adca9a44d39dee7e76aacca2189282001", null ],
    [ "Item", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetOperatorTableRowResponse.html#aa09b7f0efb036433e81c0e56ba4c7b05", null ]
];