var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetDateResponse =
[
    [ "APIGetDateResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetDateResponse.html#abbd04b772470c1fa92044e1775095c4f", null ],
    [ "APIGetDateResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetDateResponse.html#a8c2f3ce8def4b281fb419b002bc756c9", null ],
    [ "Date", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetDateResponse.html#af91e79a725be601f0a65d89433b4a08c", null ]
];