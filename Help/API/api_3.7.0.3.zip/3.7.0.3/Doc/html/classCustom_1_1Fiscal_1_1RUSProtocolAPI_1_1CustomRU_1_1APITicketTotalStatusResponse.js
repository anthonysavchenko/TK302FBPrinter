var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APITicketTotalStatusResponse =
[
    [ "APITicketTotalStatusResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APITicketTotalStatusResponse.html#a590e602d392c01cf3dffdc61fd924c2f", null ],
    [ "APITicketTotalStatusResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APITicketTotalStatusResponse.html#af0832f3e8998970b99a3516e92fed591", null ],
    [ "DiscountAmount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APITicketTotalStatusResponse.html#a053b3ad45af7c9d4d27f56531e05c4e3", null ],
    [ "DocumentNumber", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APITicketTotalStatusResponse.html#aea9fd2dc4d6bba8239f26c1d33775e6e", null ],
    [ "ExtraChargeAmount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APITicketTotalStatusResponse.html#a39f9eb21186d757979a12c8a357792e6", null ],
    [ "IsOpen", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APITicketTotalStatusResponse.html#a986ab006730d23b6aa4b204fc002cd7d", null ],
    [ "Remainder", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APITicketTotalStatusResponse.html#a599c408fe87e827eb7a119ed734b5313", null ],
    [ "ReturnAmount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APITicketTotalStatusResponse.html#a058132049a7131676e41aa13246f7227", null ],
    [ "SubTotal", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APITicketTotalStatusResponse.html#a3e1bde5ea1065708cf3cee4f4bf15346", null ],
    [ "VoidAmount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APITicketTotalStatusResponse.html#a5740027e492e1c90449d631ce2a0a3ff", null ]
];