var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetVATTableResponse =
[
    [ "APIGetVATTableResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetVATTableResponse.html#a0f42e35fd09f57f6b004375a56ebedd6", null ],
    [ "APIGetVATTableResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetVATTableResponse.html#a72ba54fef091f75386cdc730cdcd2ac2", null ],
    [ "Items", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetVATTableResponse.html#a5f6a7f45e5bf52868369dde891ca6117", null ]
];