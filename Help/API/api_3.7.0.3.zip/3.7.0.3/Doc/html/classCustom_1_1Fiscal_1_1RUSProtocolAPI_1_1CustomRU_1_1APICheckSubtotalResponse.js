var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APICheckSubtotalResponse =
[
    [ "APICheckSubtotalResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APICheckSubtotalResponse.html#a1371f5f47a5b179337e0bd1c18f04120", null ],
    [ "APICheckSubtotalResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APICheckSubtotalResponse.html#ac76ad31d64feb6779954f3cea15017f7", null ],
    [ "DocumentNumber", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APICheckSubtotalResponse.html#a3cfaacc2ef6d9bd28263748877eef02f", null ],
    [ "SessionNumber", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APICheckSubtotalResponse.html#a4827b7342435ef3f9e188626ec6ddb63", null ],
    [ "SubtotalAmount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APICheckSubtotalResponse.html#a4dab5a7416755fd25b96211de9c155f1", null ]
];