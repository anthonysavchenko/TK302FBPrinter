var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIAdvancedResponse =
[
    [ "APIAdvancedResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIAdvancedResponse.html#a75932afcefdde830b1e80766a63f8668", null ],
    [ "APIAdvancedResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIAdvancedResponse.html#a572b2c8ce7ccaddcee9ac16dc30d9f04", null ],
    [ "Value", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIAdvancedResponse.html#a62c4877a2751e9bc0d1d69ae83c3ce88", null ]
];