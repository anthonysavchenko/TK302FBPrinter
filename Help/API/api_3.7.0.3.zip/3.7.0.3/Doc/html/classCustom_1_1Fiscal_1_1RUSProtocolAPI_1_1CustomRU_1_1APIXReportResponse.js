var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIXReportResponse =
[
    [ "APIXReportResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIXReportResponse.html#a5a5e54bcaf0073a79173b771bf7d387c", null ],
    [ "APIXReportResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIXReportResponse.html#a210e01dc2aefb0135008ffcb0013bb30", null ],
    [ "IsDayOpen", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIXReportResponse.html#a7c612e7c7cc576dc89539ff7cadfba55", null ],
    [ "SessionNumber", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIXReportResponse.html#a90c529e4ddeeea2b94600a22bf12eb2f", null ]
];