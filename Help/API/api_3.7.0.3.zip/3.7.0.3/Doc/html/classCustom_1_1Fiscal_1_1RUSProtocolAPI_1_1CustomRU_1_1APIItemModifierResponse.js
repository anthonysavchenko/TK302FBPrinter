var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIItemModifierResponse =
[
    [ "APIItemModifierResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIItemModifierResponse.html#a15bd1334233eb384d774d96735607de6", null ],
    [ "APIItemModifierResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIItemModifierResponse.html#a5c2fc4ddabddb6d911ca2213d69f9f72", null ],
    [ "CurrentAddOnAmount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIItemModifierResponse.html#abfd51ad22e11fa2b1841a56737992441", null ],
    [ "CurrentDiscountAmount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIItemModifierResponse.html#add41ca2fe7eace03a0d8df59ed8ae9d8", null ],
    [ "DocumentNumber", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIItemModifierResponse.html#a844faa602c0425173536842a2f53acab", null ],
    [ "SessionNumber", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIItemModifierResponse.html#a80cce0aebe6efed205b31aa414a77c3e", null ],
    [ "SubtotalAmount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIItemModifierResponse.html#a4a3d504c02a4ce29edde5dece66fd73d", null ]
];