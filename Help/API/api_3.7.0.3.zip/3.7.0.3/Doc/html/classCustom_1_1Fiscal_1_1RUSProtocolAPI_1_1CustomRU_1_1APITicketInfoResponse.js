var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APITicketInfoResponse =
[
    [ "APITicketInfoResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APITicketInfoResponse.html#af81169e081b67845dff11d2d3f13e920", null ],
    [ "APITicketInfoResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APITicketInfoResponse.html#a1b0dde9797fcceb48449ca41fbf65a97", null ],
    [ "DocumentDayCount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APITicketInfoResponse.html#aa3d6f0b7047b7248ea1077d824ad31fe", null ],
    [ "LastFDDocumentNumber", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APITicketInfoResponse.html#a9c235ef789da8e5cd4553666fd0e520f", null ],
    [ "LastFDFiscalSignature", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APITicketInfoResponse.html#ab80daaffd5649626cf361a03b8ab3a47", null ],
    [ "ReasonOfdRefusal", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APITicketInfoResponse.html#af7ef37d840ea35b854bb80bb7137a4b9", null ],
    [ "TicketDayCount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APITicketInfoResponse.html#ae8d3d266de050abdcf466524904aaec3", null ],
    [ "TicketType", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APITicketInfoResponse.html#a737d87eb87ab2787bb258790b0575b07", null ]
];