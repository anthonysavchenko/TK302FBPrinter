var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIStatisticReportResponse =
[
    [ "APIStatisticReportResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIStatisticReportResponse.html#ad2d8e779291c9a0c64f0ed6d4567e736", null ],
    [ "APIStatisticReportResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIStatisticReportResponse.html#a569cb684f1182402a8a19ad472265f22", null ],
    [ "PurchaseAmount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIStatisticReportResponse.html#abd17be9af36a78b79857124452a23afa", null ],
    [ "PurchaseCount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIStatisticReportResponse.html#ac2c82631064f4cac1f3cdfc6349c203f", null ],
    [ "PurchaseReturnAmount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIStatisticReportResponse.html#add52bb6d1fdb4601105f6b33abd12972", null ],
    [ "PurchaseReturnCount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIStatisticReportResponse.html#a898c47f30256b82d43aec3856b7251d9", null ],
    [ "SaleAmount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIStatisticReportResponse.html#aee79db41d63b0c74c74893206c0ddb57", null ],
    [ "SaleCount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIStatisticReportResponse.html#ac1371036984d20283e1052f4391bc88d", null ],
    [ "SaleReturnAmount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIStatisticReportResponse.html#a30b066e9a892dce741780d13d6c01327", null ],
    [ "SaleReturnCount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIStatisticReportResponse.html#a9c8aaf4d27a51e4c0bd7c3e3d2029b85", null ]
];