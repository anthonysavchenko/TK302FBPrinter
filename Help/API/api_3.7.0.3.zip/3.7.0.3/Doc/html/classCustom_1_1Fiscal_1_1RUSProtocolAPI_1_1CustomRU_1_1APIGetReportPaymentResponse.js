var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetReportPaymentResponse =
[
    [ "APIGetReportPaymentResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetReportPaymentResponse.html#a7629f1fb173639b06552a98780b79dfd", null ],
    [ "APIGetReportPaymentResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetReportPaymentResponse.html#a379416a7b68bf54bb814434942bf9084", null ],
    [ "DocumentNumber", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetReportPaymentResponse.html#acf263f05bee8a40bb0dd14423cae08be", null ],
    [ "FiscalSignature", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetReportPaymentResponse.html#a15d561cc89743e152ddfb5f8030d8400", null ]
];