var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIBaseResponse =
[
    [ "APIBaseResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIBaseResponse.html#a44e1be47437b3b696c29ae67a4c95cee", null ],
    [ "ErrorCode", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIBaseResponse.html#aacd35a1889bcf13c254d85980fee2a8f", null ],
    [ "ErrorDescription", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIBaseResponse.html#ae872d6d71781ef8b746a2e87d73c3623", null ],
    [ "OperatorCode", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIBaseResponse.html#a84c6474745143b96624ea0e2dd15b244", null ]
];