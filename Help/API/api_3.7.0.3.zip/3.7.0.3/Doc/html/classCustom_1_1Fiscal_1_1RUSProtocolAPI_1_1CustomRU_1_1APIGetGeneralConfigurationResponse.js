var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetGeneralConfigurationResponse =
[
    [ "APIGetGeneralConfigurationResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetGeneralConfigurationResponse.html#a04e3648e23212af910cfbf56548318e7", null ],
    [ "APIGetGeneralConfigurationResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetGeneralConfigurationResponse.html#a7207ea8d7a788e90431841c4e0d39695", null ],
    [ "CashDrawerVoltage", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetGeneralConfigurationResponse.html#a3062748255a8bd30e1e83106042f4c63", null ],
    [ "DisplayBacklight", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetGeneralConfigurationResponse.html#aebb3eb9dc370b02ec614cb1cdc66fce7", null ],
    [ "DisplayContrast", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetGeneralConfigurationResponse.html#aa7b91bb8be27e7648c4e8bc664eaf3c2", null ],
    [ "ExtraInfo", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetGeneralConfigurationResponse.html#a4ef8d6841aae16aa520849a0faa19ca6", null ],
    [ "FPUMode", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetGeneralConfigurationResponse.html#a828c626bc9a96dd641cf19eefabee985", null ],
    [ "MandatorySubtotal", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetGeneralConfigurationResponse.html#a298cd35cc1e13cc59e595f94e128ef9e", null ],
    [ "NegativeCashDrawer", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetGeneralConfigurationResponse.html#a2fe035eb6c039d21b01bfecc68389c59", null ]
];