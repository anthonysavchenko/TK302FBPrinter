var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIPayment =
[
    [ "Amount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIPayment.html#aa00b0da44d10f276dc78f0fe07489988", null ],
    [ "ChangeForbidden", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIPayment.html#a576a7bf3a56f5a36d7a2cb6944faf0a6", null ],
    [ "Description", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIPayment.html#a104231a924b1c3d83d81ac1941b283ad", null ],
    [ "DrawerOnlyPOS", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIPayment.html#a37d1f2871a2c889e2c2b487e77827e26", null ],
    [ "Enabled", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIPayment.html#ac94cf7ff5d887b84e149b73d3dfdd742", null ],
    [ "MandatoryAmount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIPayment.html#adc71431f1454e3e5f2418411d14899e7", null ],
    [ "MandatorySubTotal", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIPayment.html#adcd7b8d92c78ad6ededb0efa72606c44", null ],
    [ "MaxAmount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIPayment.html#aa5ffc5c1895366eca6e773d31164707e", null ],
    [ "NoCash", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIPayment.html#a734452b5ce70310858d70749d2040714", null ],
    [ "OpenCashDrawer", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIPayment.html#a0515bbc6bff5ba31a6336f9798567dfe", null ],
    [ "ReservedToOperator", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIPayment.html#a29bed8402a0b3794b8ee076e70f49fea", null ]
];