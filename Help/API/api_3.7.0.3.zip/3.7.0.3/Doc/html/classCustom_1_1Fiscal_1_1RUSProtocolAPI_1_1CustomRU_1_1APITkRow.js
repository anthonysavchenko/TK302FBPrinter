var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APITkRow =
[
    [ "Font", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APITkRow.html#ada5ba31f8b3ae0691e422a991cdc0579", null ],
    [ "LayoutType", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APITkRow.html#af781da243d32a48c9486e5b070f7d716", null ],
    [ "Text", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APITkRow.html#a8a2a26357b1f7d8036fd0c132f00c72e", null ]
];