var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetTK302RS232ConfigurationResponse =
[
    [ "APIGetTK302RS232ConfigurationResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetTK302RS232ConfigurationResponse.html#aa4804b135e975e99920c678f2af26639", null ],
    [ "APIGetTK302RS232ConfigurationResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetTK302RS232ConfigurationResponse.html#a6d3d50990a4f876393f4746dd8cb1240", null ],
    [ "Baudrate", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetTK302RS232ConfigurationResponse.html#ace1ad69b77c9fa1e7f54ab50364bd667", null ],
    [ "BitNumber", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetTK302RS232ConfigurationResponse.html#a9241bf56dda6d28421488cfcd56df2f1", null ],
    [ "BusyCondition", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetTK302RS232ConfigurationResponse.html#a8495bcb5bc88b2f92ed1e36cbceb5539", null ],
    [ "DataLength", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetTK302RS232ConfigurationResponse.html#ad7edc5b9761a0d93f02be3c96f9514b9", null ],
    [ "Handshake", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetTK302RS232ConfigurationResponse.html#aecaa70f1597242e5d7d61f78b7b40543", null ],
    [ "Parity", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetTK302RS232ConfigurationResponse.html#af0c02f76b10eacec29a4516a2134865e", null ]
];