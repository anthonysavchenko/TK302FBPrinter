var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APILastFMReceiptDataResponse =
[
    [ "APILastFMReceiptDataResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APILastFMReceiptDataResponse.html#ae07019560e0fd57138a7ece801b78330", null ],
    [ "APILastFMReceiptDataResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APILastFMReceiptDataResponse.html#a68451c0ba0346b1197329bfb0eb29919", null ],
    [ "Date", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APILastFMReceiptDataResponse.html#aff2a3be197397c8b7eb59b3939132a04", null ],
    [ "DocumentNumber", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APILastFMReceiptDataResponse.html#a32d86e7e526c0b4749009688fb9bffa7", null ],
    [ "ECRRegistrationNumber", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APILastFMReceiptDataResponse.html#ae9fa2dfc98edd1aa68ee0a11d6ec141e", null ],
    [ "FiscalDocumentNumber", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APILastFMReceiptDataResponse.html#a24635eafdb5977efd53aff9f67ef00e2", null ],
    [ "FiscalSignature", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APILastFMReceiptDataResponse.html#a42746f42a709b28b737bb95e11da9189", null ],
    [ "FNSerialNumber", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APILastFMReceiptDataResponse.html#a0a241edc3a090b778f5ef9331574539c", null ],
    [ "TaxationAuthorityWS", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APILastFMReceiptDataResponse.html#a225104469b45b2630a9c791f1a0913b4", null ],
    [ "TaxationType", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APILastFMReceiptDataResponse.html#acc0d2684837ab3ce61289876884cebe2", null ],
    [ "UserTIN", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APILastFMReceiptDataResponse.html#afd04891c8cb94558e339c8593206473f", null ]
];