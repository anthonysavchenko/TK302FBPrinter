var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIReceiptStatusResponse =
[
    [ "APIReceiptStatusResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIReceiptStatusResponse.html#a578032c37c85625d5c990c7ca616c085", null ],
    [ "APIReceiptStatusResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIReceiptStatusResponse.html#a502b01a252ebc29f923e514f66040be9", null ],
    [ "FiscalReceiptInProgress", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIReceiptStatusResponse.html#aef20345f493dcf564cb2ba84b62727b3", null ],
    [ "FiscalReceiptStep", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIReceiptStatusResponse.html#a68687b95b162c4141df241ac68c7e69e", null ],
    [ "NotFiscalReceiptInProgress", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIReceiptStatusResponse.html#a32d5b093c13fbf6e8b19f6d44aa1715b", null ]
];