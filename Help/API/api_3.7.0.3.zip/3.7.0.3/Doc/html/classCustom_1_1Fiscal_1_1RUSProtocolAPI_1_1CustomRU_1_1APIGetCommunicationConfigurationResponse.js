var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetCommunicationConfigurationResponse =
[
    [ "APIGetCommunicationConfigurationResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetCommunicationConfigurationResponse.html#aaecb8073e8b17b8f609df2d802bf55c0", null ],
    [ "APIGetCommunicationConfigurationResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetCommunicationConfigurationResponse.html#a8dd357d5c7259fc12c387d26923d4210", null ],
    [ "Baudrate", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetCommunicationConfigurationResponse.html#a427442609d7dcd6535b44be8a0790a94", null ],
    [ "BitNumber", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetCommunicationConfigurationResponse.html#a5ed80659ab429521d77c7f3dc790c3a0", null ],
    [ "DisplayLine", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetCommunicationConfigurationResponse.html#a08669ec88d9d08bf4cffe483241f75e8", null ],
    [ "Handshake", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetCommunicationConfigurationResponse.html#a282208e72d05c57dae18589595a645d6", null ],
    [ "PaperMissing", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetCommunicationConfigurationResponse.html#a7a9ce02e7f7c5fb85c1f000b202a1aac", null ],
    [ "PCChannel", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetCommunicationConfigurationResponse.html#a506a0d07e5ddc678b14bc752b60de99c", null ],
    [ "Protocol", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetCommunicationConfigurationResponse.html#a4533347a6a4016dedc1d38fa88ba738a", null ],
    [ "TXEcho", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetCommunicationConfigurationResponse.html#aa54a936ba145b049741859e561bc7539", null ],
    [ "TXFooter", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetCommunicationConfigurationResponse.html#a87f9f5abc3e58d22f7b9b86bd952152c", null ]
];