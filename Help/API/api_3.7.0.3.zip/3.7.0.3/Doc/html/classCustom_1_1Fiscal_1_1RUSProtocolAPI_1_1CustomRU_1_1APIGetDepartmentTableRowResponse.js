var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetDepartmentTableRowResponse =
[
    [ "APIGetDepartmentTableRowResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetDepartmentTableRowResponse.html#a15c63e8bdecfe48503108a67013ead6e", null ],
    [ "APIGetDepartmentTableRowResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetDepartmentTableRowResponse.html#ac80e092d8226725f93b8ff577bc84271", null ],
    [ "Item", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetDepartmentTableRowResponse.html#ae5e56bb58b7a8542ce5b803674be371f", null ]
];