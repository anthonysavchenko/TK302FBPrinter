var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIOperator =
[
    [ "Code", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIOperator.html#a4fe3ae462e5ef2a365ae96d4ecd529be", null ],
    [ "Department", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIOperator.html#a3a718ef534fcd4e738b2f72933161004", null ],
    [ "Description", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIOperator.html#a502b9e236bca78c053e1f6037953df31", null ],
    [ "DiscMarkup", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIOperator.html#a98a2aef8050ef9b1e8c57e35d1c67f50", null ],
    [ "FiscalZerosetting", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIOperator.html#ac70580fb419f6fd483fab4c3c6b8ad24", null ],
    [ "Macro", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIOperator.html#ae0206cf4386f94fa133ae9272c6c1adb", null ],
    [ "OperatorReport", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIOperator.html#aa1ba1d68653b9f52730e82462289d8a7", null ],
    [ "OperatorZeroset", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIOperator.html#a055cff59be93efff7f1128d782136991", null ],
    [ "Password", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIOperator.html#a7b51e53d9e1117c7b858fe3967051f22", null ],
    [ "Payment", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIOperator.html#a6eebdb0b47220b65bfdabb31d9d9f02a", null ],
    [ "Program", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIOperator.html#a3d7709d77198069920d78330878acad0", null ],
    [ "ProgrammingMode", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIOperator.html#aec0a2cfad23cdcb76a68c65dc2b2457f", null ],
    [ "ReadingMode", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIOperator.html#a8d7b455d067f48b70b8d3a25c9b6d1ba", null ],
    [ "Refunds", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIOperator.html#af922cda1f7c97077b25f8d5534f31152", null ],
    [ "RegisteringMode", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIOperator.html#a58a3a57b9e49a621bee027652b2fef05", null ],
    [ "SubtotalDiscMarkup", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIOperator.html#a87d602902ddd1bd84c82a838732dae4e", null ],
    [ "Temporary", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIOperator.html#af9970226ab240478cd32adc6ee7cdddf", null ],
    [ "TinCashier", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIOperator.html#aafa1a5107beb68d5136e6f23f25c4de7", null ],
    [ "Void", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIOperator.html#a92925f446fabc304bfc1aad295675c4b", null ],
    [ "WriteOffs", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIOperator.html#a949331b9ee3241701cad04379296b1e9", null ],
    [ "ZerosettingMode", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIOperator.html#a8f531d9117222154bd4eb1a16e1f91cf", null ]
];