var searchData=
[
  ['rusprotocolapi_20documentation',['RUSProtocolAPI Documentation',['../index.html',1,'']]],
  ['readingmode',['ReadingMode',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIOperator.html#a8d7b455d067f48b70b8d3a25c9b6d1ba',1,'Custom::Fiscal::RUSProtocolAPI::CustomRU::APIOperator']]],
  ['readtesthardwareresult',['ReadTestHardwareResult',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1ProtocolAPI.html#a97bc6fab8dd0df26c3d8fd72aead75c0',1,'Custom::Fiscal::RUSProtocolAPI::ProtocolAPI']]],
  ['receiptitemtypeenum',['ReceiptItemTypeEnum',['../namespaceCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1Enums.html#aae5ed4ee1f22f5ea4ff0120825a77584',1,'Custom::Fiscal::RUSProtocolAPI::Enums']]],
  ['receipttypeenum',['ReceiptTypeEnum',['../namespaceCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1Enums.html#ac5dfc8fd7e58af9545cb55e5c5281881',1,'Custom::Fiscal::RUSProtocolAPI::Enums']]],
  ['refunds',['Refunds',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIOperator.html#af922cda1f7c97077b25f8d5534f31152',1,'Custom::Fiscal::RUSProtocolAPI::CustomRU::APIOperator']]],
  ['registeringmode',['RegisteringMode',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIOperator.html#a58a3a57b9e49a621bee027652b2fef05',1,'Custom::Fiscal::RUSProtocolAPI::CustomRU::APIOperator']]],
  ['registrationclose',['RegistrationClose',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1ProtocolAPI.html#ae09bf2bb9e64345c5344dd6a7a8ecd8e',1,'Custom::Fiscal::RUSProtocolAPI::ProtocolAPI']]],
  ['registrationopen',['RegistrationOpen',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1ProtocolAPI.html#a9d374916ed6f034b1d186424e7bbe9fc',1,'Custom::Fiscal::RUSProtocolAPI::ProtocolAPI']]],
  ['registrationreasonenum',['RegistrationReasonEnum',['../namespaceCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1Enums.html#ae0a00bf9a6b05ac64fc342fc0068474a',1,'Custom::Fiscal::RUSProtocolAPI::Enums']]],
  ['registrationtypeenum',['RegistrationTypeEnum',['../namespaceCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1Enums.html#af621a0052fa20ea5a08734404cee5695',1,'Custom::Fiscal::RUSProtocolAPI::Enums']]],
  ['repeatdocument',['RepeatDocument',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1ProtocolAPI.html#a10a7e36e397a20fe926c4e0848736d80',1,'Custom::Fiscal::RUSProtocolAPI::ProtocolAPI']]],
  ['repeatdocumentenum',['RepeatDocumentEnum',['../namespaceCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1Enums.html#aa1523f4db52a9287ab5bd4187b6ac142',1,'Custom::Fiscal::RUSProtocolAPI::Enums']]],
  ['reservedtooperator',['ReservedToOperator',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIPayment.html#a29bed8402a0b3794b8ee076e70f49fea',1,'Custom::Fiscal::RUSProtocolAPI::CustomRU::APIPayment']]],
  ['roundingenum',['RoundingEnum',['../namespaceCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1Enums.html#a285254343413d7faa5058c5b4320e856',1,'Custom::Fiscal::RUSProtocolAPI::Enums']]],
  ['rusprotocolexception',['RUSProtocolException',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1RUSProtocolException.html',1,'Custom::Fiscal::RUSProtocolAPI']]]
];
