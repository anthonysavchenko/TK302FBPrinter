var searchData=
[
  ['gateway',['Gateway',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetEthernetConfigurationResponse.html#a32d0e02ce9513444ce7b873bb0707375',1,'Custom.Fiscal.RUSProtocolAPI.CustomRU.APIGetEthernetConfigurationResponse.Gateway()'],['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetTK302EthernetConfigurationResponse.html#ac6ac4be92f4e72f805c8041f9af5c84f',1,'Custom.Fiscal.RUSProtocolAPI.CustomRU.APIGetTK302EthernetConfigurationResponse.Gateway()']]]
];
