var searchData=
[
  ['portstatuseventargs',['PortStatusEventArgs',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1Comunication_1_1PortStatusEventArgs.html',1,'Custom.Fiscal.RUSProtocolAPI.Comunication.PortStatusEventArgs'],['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1PortStatusEventArgs.html',1,'Custom.Fiscal.RUSProtocolAPI.PortStatusEventArgs']]],
  ['protocolapi',['ProtocolAPI',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1ProtocolAPI.html',1,'Custom::Fiscal::RUSProtocolAPI']]]
];
