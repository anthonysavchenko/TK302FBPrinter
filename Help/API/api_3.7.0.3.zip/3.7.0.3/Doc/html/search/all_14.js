var searchData=
[
  ['xreport',['XReport',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1ProtocolAPI.html#a3998f2a3b67ab91ddace0692868426f0',1,'Custom.Fiscal.RUSProtocolAPI.ProtocolAPI.XReport(string operatorPassword)'],['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1ProtocolAPI.html#a0d7e3d5a41f1cd74773073aed234ed52',1,'Custom.Fiscal.RUSProtocolAPI.ProtocolAPI.XReport(string operatorPassword, bool AddCashDrawer)']]]
];
