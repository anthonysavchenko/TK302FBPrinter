var searchData=
[
  ['operationresult',['OperationResult',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1OperationResult.html',1,'Custom::Fiscal::RUSProtocolAPI']]]
];
