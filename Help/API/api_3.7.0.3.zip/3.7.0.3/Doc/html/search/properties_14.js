var searchData=
[
  ['zerosettingmode',['ZerosettingMode',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIOperator.html#a8f531d9117222154bd4eb1a16e1f91cf',1,'Custom::Fiscal::RUSProtocolAPI::CustomRU::APIOperator']]]
];
