var searchData=
[
  ['lastfiscaldocumentenum',['LastFiscalDocumentEnum',['../namespaceCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1Enums.html#ab3d9a494bc8b7bb2101410ebe1a12466',1,'Custom::Fiscal::RUSProtocolAPI::Enums']]],
  ['loglevelenum',['LogLevelEnum',['../namespaceCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1Enums.html#acb26ddb5235f076c03f39e7300308ebd',1,'Custom::Fiscal::RUSProtocolAPI::Enums']]]
];
