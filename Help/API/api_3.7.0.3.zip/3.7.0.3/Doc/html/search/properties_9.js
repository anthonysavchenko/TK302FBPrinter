var searchData=
[
  ['layouttype',['LayoutType',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APITkRow.html#af781da243d32a48c9486e5b070f7d716',1,'Custom::Fiscal::RUSProtocolAPI::CustomRU::APITkRow']]],
  ['loglevel',['LogLevel',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1ProtocolAPI.html#a3a8e885f54308f13cc273400b8aa122e',1,'Custom::Fiscal::RUSProtocolAPI::ProtocolAPI']]]
];
