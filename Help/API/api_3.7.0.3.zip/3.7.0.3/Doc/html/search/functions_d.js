var searchData=
[
  ['voidlastitem',['VoidLastItem',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1ProtocolAPI.html#ab9cb18e762dfbd539ad810c611dc0bc1',1,'Custom::Fiscal::RUSProtocolAPI::ProtocolAPI']]]
];
