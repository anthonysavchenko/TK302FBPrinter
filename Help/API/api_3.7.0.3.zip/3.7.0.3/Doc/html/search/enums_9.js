var searchData=
[
  ['receiptitemtypeenum',['ReceiptItemTypeEnum',['../namespaceCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1Enums.html#aae5ed4ee1f22f5ea4ff0120825a77584',1,'Custom::Fiscal::RUSProtocolAPI::Enums']]],
  ['receipttypeenum',['ReceiptTypeEnum',['../namespaceCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1Enums.html#ac5dfc8fd7e58af9545cb55e5c5281881',1,'Custom::Fiscal::RUSProtocolAPI::Enums']]],
  ['registrationreasonenum',['RegistrationReasonEnum',['../namespaceCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1Enums.html#ae0a00bf9a6b05ac64fc342fc0068474a',1,'Custom::Fiscal::RUSProtocolAPI::Enums']]],
  ['registrationtypeenum',['RegistrationTypeEnum',['../namespaceCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1Enums.html#af621a0052fa20ea5a08734404cee5695',1,'Custom::Fiscal::RUSProtocolAPI::Enums']]],
  ['repeatdocumentenum',['RepeatDocumentEnum',['../namespaceCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1Enums.html#aa1523f4db52a9287ab5bd4187b6ac142',1,'Custom::Fiscal::RUSProtocolAPI::Enums']]],
  ['roundingenum',['RoundingEnum',['../namespaceCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1Enums.html#a285254343413d7faa5058c5b4320e856',1,'Custom::Fiscal::RUSProtocolAPI::Enums']]]
];
