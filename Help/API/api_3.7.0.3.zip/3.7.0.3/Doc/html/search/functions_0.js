var searchData=
[
  ['apiconfiguration',['APIConfiguration',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1AppConfig_1_1APIConfiguration.html#ad7993119ccd3cdd13cbae3eb7e96e071',1,'Custom::Fiscal::RUSProtocolAPI::AppConfig::APIConfiguration']]]
];
