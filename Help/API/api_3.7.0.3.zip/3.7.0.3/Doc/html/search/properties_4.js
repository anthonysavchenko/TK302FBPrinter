var searchData=
[
  ['enabled',['Enabled',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIPayment.html#ac94cf7ff5d887b84e149b73d3dfdd742',1,'Custom::Fiscal::RUSProtocolAPI::CustomRU::APIPayment']]],
  ['extrainfo',['ExtraInfo',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetGeneralConfigurationResponse.html#a4ef8d6841aae16aa520849a0faa19ca6',1,'Custom::Fiscal::RUSProtocolAPI::CustomRU::APIGetGeneralConfigurationResponse']]]
];
