var searchData=
[
  ['ofddatatypeenum',['OFDDataTypeEnum',['../namespaceCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1Enums.html#aa5333cb2e8a811d8f8af05138b4c6fec',1,'Custom::Fiscal::RUSProtocolAPI::Enums']]]
];
