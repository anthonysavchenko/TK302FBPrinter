var searchData=
[
  ['handshake',['Handshake',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetCommunicationConfigurationResponse.html#a282208e72d05c57dae18589595a645d6',1,'Custom.Fiscal.RUSProtocolAPI.CustomRU.APIGetCommunicationConfigurationResponse.Handshake()'],['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetTK302RS232ConfigurationResponse.html#aecaa70f1597242e5d7d61f78b7b40543',1,'Custom.Fiscal.RUSProtocolAPI.CustomRU.APIGetTK302RS232ConfigurationResponse.Handshake()']]]
];
