var searchData=
[
  ['usbprofileenum',['UsbProfileEnum',['../namespaceCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1Enums.html#a0e72b8c7b870292cb4f86bd5d6d37fed',1,'Custom::Fiscal::RUSProtocolAPI::Enums']]]
];
