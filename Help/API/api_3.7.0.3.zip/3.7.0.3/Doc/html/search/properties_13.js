var searchData=
[
  ['writeoffs',['WriteOffs',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIOperator.html#a949331b9ee3241701cad04379296b1e9',1,'Custom::Fiscal::RUSProtocolAPI::CustomRU::APIOperator']]],
  ['writeoffsoperatortype',['WriteOffsOperatorType',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIDepartment.html#acfa19f22cd5690ccbe4acf69338f2697',1,'Custom::Fiscal::RUSProtocolAPI::CustomRU::APIDepartment']]]
];
