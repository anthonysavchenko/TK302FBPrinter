var searchData=
[
  ['codeofgoodsenum',['CodeOfGoodsEnum',['../namespaceCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1Enums.html#a8f58902cdc75ab46e5d8eeeb81157542',1,'Custom::Fiscal::RUSProtocolAPI::Enums']]],
  ['comunicationtypeenum',['ComunicationTypeEnum',['../namespaceCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1Enums.html#a5aa130b3f8239ff233c48bcde82d7cb2',1,'Custom::Fiscal::RUSProtocolAPI::Enums']]],
  ['correctionreceipttypeenum',['CorrectionReceiptTypeEnum',['../namespaceCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1Enums.html#a5606c5df2314198221110e080e6130cb',1,'Custom::Fiscal::RUSProtocolAPI::Enums']]],
  ['correctiontypeenum',['CorrectionTypeEnum',['../namespaceCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1Enums.html#a2421baee94a3e44eb38cda04bb3b8504',1,'Custom::Fiscal::RUSProtocolAPI::Enums']]]
];
