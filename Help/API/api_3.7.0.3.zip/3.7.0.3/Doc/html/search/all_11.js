var searchData=
[
  ['usbaddress',['UsbAddress',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetTK302USBConfigurationResponse.html#a4c643f1132bfc88550905b94587d9ba9',1,'Custom::Fiscal::RUSProtocolAPI::CustomRU::APIGetTK302USBConfigurationResponse']]],
  ['usbclass',['UsbClass',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetTK302USBConfigurationResponse.html#a92420769267b3363e5f4860870a6ca9c',1,'Custom::Fiscal::RUSProtocolAPI::CustomRU::APIGetTK302USBConfigurationResponse']]],
  ['usbprofileenum',['UsbProfileEnum',['../namespaceCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1Enums.html#a0e72b8c7b870292cb4f86bd5d6d37fed',1,'Custom::Fiscal::RUSProtocolAPI::Enums']]]
];
