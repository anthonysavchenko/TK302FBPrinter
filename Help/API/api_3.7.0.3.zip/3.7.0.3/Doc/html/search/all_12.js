var searchData=
[
  ['vatcode',['VatCode',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIDepartment.html#a2195d25b96cba7e463f55417baf90e95',1,'Custom::Fiscal::RUSProtocolAPI::CustomRU::APIDepartment']]],
  ['void',['Void',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIOperator.html#a92925f446fabc304bfc1aad295675c4b',1,'Custom::Fiscal::RUSProtocolAPI::CustomRU::APIOperator']]],
  ['voidlastitem',['VoidLastItem',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1ProtocolAPI.html#ab9cb18e762dfbd539ad810c611dc0bc1',1,'Custom::Fiscal::RUSProtocolAPI::ProtocolAPI']]],
  ['voidoperatortype',['VoidOperatorType',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIDepartment.html#a385647fd0f8652f1d59b6ab92a9f6f02',1,'Custom::Fiscal::RUSProtocolAPI::CustomRU::APIDepartment']]]
];
