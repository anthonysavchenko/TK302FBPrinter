var searchData=
[
  ['singleitemreceipt',['SingleItemReceipt',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIDepartment.html#a8b439357e03699918e5bdbb14dadf31b',1,'Custom::Fiscal::RUSProtocolAPI::CustomRU::APIDepartment']]],
  ['speed',['Speed',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetTK302PaperConfigurationResponse.html#a085a73581ebd730adc3a79f300f64b51',1,'Custom::Fiscal::RUSProtocolAPI::CustomRU::APIGetTK302PaperConfigurationResponse']]],
  ['status',['Status',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIShiftStatusResponse.html#a60656d778f2fb0e1b7534d0d13c1e336',1,'Custom::Fiscal::RUSProtocolAPI::CustomRU::APIShiftStatusResponse']]],
  ['subtotaldiscmarkup',['SubtotalDiscMarkup',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIOperator.html#a87d602902ddd1bd84c82a838732dae4e',1,'Custom::Fiscal::RUSProtocolAPI::CustomRU::APIOperator']]]
];
