var searchData=
[
  ['interlinecompression',['InterlineCompression',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetPrinterParamsResponse.html#af1f0fe3597802647f1af9780da8cfc9c',1,'Custom::Fiscal::RUSProtocolAPI::CustomRU::APIGetPrinterParamsResponse']]],
  ['ipaddress',['IPAddress',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetEthernetConfigurationResponse.html#a220537a6a77846e062dc71b645ba21a0',1,'Custom.Fiscal.RUSProtocolAPI.CustomRU.APIGetEthernetConfigurationResponse.IPAddress()'],['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetTK302EthernetConfigurationResponse.html#aee72c87e60a1422cd9f8f5b29f921cde',1,'Custom.Fiscal.RUSProtocolAPI.CustomRU.APIGetTK302EthernetConfigurationResponse.IPAddress()']]]
];
