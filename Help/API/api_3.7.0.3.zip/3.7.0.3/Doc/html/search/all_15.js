var searchData=
[
  ['zerosettingmode',['ZerosettingMode',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIOperator.html#a8f531d9117222154bd4eb1a16e1f91cf',1,'Custom::Fiscal::RUSProtocolAPI::CustomRU::APIOperator']]],
  ['zreport',['ZReport',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1ProtocolAPI.html#a1cab941bc42a2616990229159427cc0e',1,'Custom.Fiscal.RUSProtocolAPI.ProtocolAPI.ZReport(string operatorPassword, bool print, bool saveOnFile)'],['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1ProtocolAPI.html#adfbf706859d01d46ff536f12b579fec5',1,'Custom.Fiscal.RUSProtocolAPI.ProtocolAPI.ZReport(string operatorPassword, bool print, bool saveOnFile, bool AddCashDrawer)'],['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1ProtocolAPI.html#a7eb81e9117e9395f57fa109043da800e',1,'Custom.Fiscal.RUSProtocolAPI.ProtocolAPI.ZReport(string operatorPassword, bool print, bool saveOnFile, bool AddCashDrawer, bool SaveOnSD, bool saveTXT, bool saveTXTonSD)']]]
];
