var searchData=
[
  ['capdepartmenttablerowcount',['CapDepartmentTableRowCount',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1ProtocolAPI.html#a2c1c64316d8745f0031442fa7790f60e',1,'Custom::Fiscal::RUSProtocolAPI::ProtocolAPI']]],
  ['capfootertablerowcount',['CapFooterTableRowCount',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1ProtocolAPI.html#aa7b86c8824e1ea2c7e31d8f4fa68afe9',1,'Custom::Fiscal::RUSProtocolAPI::ProtocolAPI']]],
  ['capheadertablerowcount',['CapHeaderTableRowCount',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1ProtocolAPI.html#a1ee7f3aacedcb38252e016aeb9f175c9',1,'Custom::Fiscal::RUSProtocolAPI::ProtocolAPI']]],
  ['capoperatortablerowcount',['CapOperatorTableRowCount',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1ProtocolAPI.html#a23b7999a6192320fc998e1380d2ae77d',1,'Custom::Fiscal::RUSProtocolAPI::ProtocolAPI']]],
  ['cappaymenttablerowcount',['CapPaymentTableRowCount',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1ProtocolAPI.html#aa72cebdfdeb123f43939e8492ece4c81',1,'Custom::Fiscal::RUSProtocolAPI::ProtocolAPI']]],
  ['capvattablerowcount',['CapVATTableRowCount',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1ProtocolAPI.html#a190e142bb6a6342276bfb317c7c45ad5',1,'Custom::Fiscal::RUSProtocolAPI::ProtocolAPI']]],
  ['cashdrawervoltage',['CashDrawerVoltage',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetGeneralConfigurationResponse.html#a3062748255a8bd30e1e83106042f4c63',1,'Custom::Fiscal::RUSProtocolAPI::CustomRU::APIGetGeneralConfigurationResponse']]],
  ['changeforbidden',['ChangeForbidden',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIPayment.html#a576a7bf3a56f5a36d7a2cb6944faf0a6',1,'Custom::Fiscal::RUSProtocolAPI::CustomRU::APIPayment']]],
  ['charsinch',['CharsInch',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetTK302PaperConfigurationResponse.html#aeeee04ccf23ee968ff5656b1f8f4a5f8',1,'Custom::Fiscal::RUSProtocolAPI::CustomRU::APIGetTK302PaperConfigurationResponse']]],
  ['code',['Code',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIOperator.html#a4fe3ae462e5ef2a365ae96d4ecd529be',1,'Custom::Fiscal::RUSProtocolAPI::CustomRU::APIOperator']]],
  ['comunicationparams',['ComunicationParams',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1ProtocolAPI.html#a2fa1763f589e2c3bb29cd61e33a7d53b',1,'Custom::Fiscal::RUSProtocolAPI::ProtocolAPI']]],
  ['comunicationtype',['ComunicationType',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1ProtocolAPI.html#a97b937ad289fc4af7996dde99fdf25e3',1,'Custom::Fiscal::RUSProtocolAPI::ProtocolAPI']]],
  ['cutterenabled',['CutterEnabled',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetPrinterParamsResponse.html#ad3dce0a192c9b9e5d274a2dcb2d9de79',1,'Custom.Fiscal.RUSProtocolAPI.CustomRU.APIGetPrinterParamsResponse.CutterEnabled()'],['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetTK302PaperConfigurationResponse.html#a0816f1456815c94b8dc7e232c8c3e517',1,'Custom.Fiscal.RUSProtocolAPI.CustomRU.APIGetTK302PaperConfigurationResponse.CutterEnabled()']]]
];
