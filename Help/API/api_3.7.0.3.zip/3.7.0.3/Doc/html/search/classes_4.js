var searchData=
[
  ['rusprotocolexception',['RUSProtocolException',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1RUSProtocolException.html',1,'Custom::Fiscal::RUSProtocolAPI']]]
];
