var searchData=
[
  ['beep',['Beep',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1ProtocolAPI.html#ac6231787fda2f92687bd1a3145f00c2a',1,'Custom::Fiscal::RUSProtocolAPI::ProtocolAPI']]]
];
