var searchData=
[
  ['negativecashdrawer',['NegativeCashDrawer',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetGeneralConfigurationResponse.html#a2fe035eb6c039d21b01bfecc68389c59',1,'Custom::Fiscal::RUSProtocolAPI::CustomRU::APIGetGeneralConfigurationResponse']]],
  ['netmask',['NetMask',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetEthernetConfigurationResponse.html#aacf102a8b86035afc31d7a95c873cf61',1,'Custom.Fiscal.RUSProtocolAPI.CustomRU.APIGetEthernetConfigurationResponse.NetMask()'],['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetTK302EthernetConfigurationResponse.html#a7535515b7f11143fbc5bdf0fba17036d',1,'Custom.Fiscal.RUSProtocolAPI.CustomRU.APIGetTK302EthernetConfigurationResponse.NetMask()']]],
  ['nocash',['NoCash',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIPayment.html#a734452b5ce70310858d70749d2040714',1,'Custom::Fiscal::RUSProtocolAPI::CustomRU::APIPayment']]]
];
