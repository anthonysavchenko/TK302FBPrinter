var searchData=
[
  ['tecnologicalreset',['TecnologicalReset',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1ProtocolAPI.html#a93d2e6cc70290a12a48442250ba07c64',1,'Custom::Fiscal::RUSProtocolAPI::ProtocolAPI']]],
  ['testhardware',['TestHardware',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1ProtocolAPI.html#a7f97d6dae55473368efc9864371aba26',1,'Custom::Fiscal::RUSProtocolAPI::ProtocolAPI']]]
];
