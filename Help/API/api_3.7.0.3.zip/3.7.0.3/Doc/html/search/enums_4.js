var searchData=
[
  ['handshakeenum',['HandshakeEnum',['../namespaceCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1Enums.html#a3ea3bde69c90bd21e7b86101a31a71fe',1,'Custom::Fiscal::RUSProtocolAPI::Enums']]]
];
