var searchData=
[
  ['deletefiscalmemories',['DeleteFiscalMemories',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1ProtocolAPI.html#a9fefccf1404f609c1e4945b1426ea474',1,'Custom.Fiscal.RUSProtocolAPI.ProtocolAPI.DeleteFiscalMemories(string operatorPassword, Enums.FMDeleteTypeEnum deleteType)'],['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1ProtocolAPI.html#aa29e97694a01343226095f9cd01ab886',1,'Custom.Fiscal.RUSProtocolAPI.ProtocolAPI.DeleteFiscalMemories(string operatorPassword, Enums.FMDeleteTypeEnum deleteType, bool SaveData)']]],
  ['deposit',['Deposit',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1ProtocolAPI.html#a198321c8a1191a62a093837c09265f55',1,'Custom::Fiscal::RUSProtocolAPI::ProtocolAPI']]],
  ['diskinfo',['DiskInfo',['../classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1ProtocolAPI.html#ae61a5154cf79a631b71951922f0d9b5c',1,'Custom::Fiscal::RUSProtocolAPI::ProtocolAPI']]]
];
