var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIStatisticDiscountReportResponse =
[
    [ "APIStatisticDiscountReportResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIStatisticDiscountReportResponse.html#afc42eafda1f2ddd9f4848df7d82c42a1", null ],
    [ "APIStatisticDiscountReportResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIStatisticDiscountReportResponse.html#a434ac1c1363ec711f2be1aaa9e321333", null ],
    [ "PurchaseAmount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIStatisticDiscountReportResponse.html#a975c6a747ab3741948fc05e1df9dc222", null ],
    [ "PurchaseCount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIStatisticDiscountReportResponse.html#af470e8885460fdb02b61def9f767618e", null ],
    [ "PurchaseReturnAmount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIStatisticDiscountReportResponse.html#a38ee278f36a37cdf76f25b79d6b6a030", null ],
    [ "PurchaseReturnCount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIStatisticDiscountReportResponse.html#ad52ffd8b536ecaae1d082bee490d8cb3", null ],
    [ "SaleAmount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIStatisticDiscountReportResponse.html#a09e11eac81b264c871ce7e5eed7a72c0", null ],
    [ "SaleCount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIStatisticDiscountReportResponse.html#a4ebacff37be55d49b75225a3d7450718", null ],
    [ "SaleReturnAmount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIStatisticDiscountReportResponse.html#a966d6a326f9c44d708f81ade4ff816ee", null ],
    [ "SaleReturnCount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIStatisticDiscountReportResponse.html#abdb37e3b7ac8f93d0400b7a37c7f8a4c", null ]
];