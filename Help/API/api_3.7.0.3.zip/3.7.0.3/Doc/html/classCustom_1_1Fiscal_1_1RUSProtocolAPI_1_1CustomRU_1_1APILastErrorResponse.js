var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APILastErrorResponse =
[
    [ "APILastErrorResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APILastErrorResponse.html#aad3b1f20874fe962ec1a8d9187356f5e", null ],
    [ "APILastErrorResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APILastErrorResponse.html#a5cf83cb9b1c975823c4fa62327eeb422", null ],
    [ "LastErrorCode", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APILastErrorResponse.html#ae91c2fede840a40e6e5500db4fb312c0", null ],
    [ "LastErrorDescription", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APILastErrorResponse.html#a153d6238223f1c263ac1b18c0916c642", null ]
];