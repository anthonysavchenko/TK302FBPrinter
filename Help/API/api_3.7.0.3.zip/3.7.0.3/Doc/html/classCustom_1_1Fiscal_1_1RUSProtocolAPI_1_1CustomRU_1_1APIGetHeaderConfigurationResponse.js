var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetHeaderConfigurationResponse =
[
    [ "APIGetHeaderConfigurationResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetHeaderConfigurationResponse.html#a2aaab402906afe2ffd9589a75cc0e0be", null ],
    [ "APIGetHeaderConfigurationResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetHeaderConfigurationResponse.html#a2c47c310c1bd2c868e05ed721d70b29e", null ],
    [ "Rows", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetHeaderConfigurationResponse.html#ab98556faa434c80587d472f3ba2e8bed", null ]
];