var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetTK302EthernetConfigurationResponse =
[
    [ "APIGetTK302EthernetConfigurationResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetTK302EthernetConfigurationResponse.html#a07bb6d16de44f8fbd81f0077da19d10f", null ],
    [ "APIGetTK302EthernetConfigurationResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetTK302EthernetConfigurationResponse.html#ad5d1c1d13b17152660f4c3b253d14e35", null ],
    [ "DHCPEnabled", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetTK302EthernetConfigurationResponse.html#aa418488153264d9db46911090d68154e", null ],
    [ "DNS1", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetTK302EthernetConfigurationResponse.html#abd848a9f81ecb36030289db8488e7880", null ],
    [ "DNS2", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetTK302EthernetConfigurationResponse.html#ac653dac1b4dddb3390a02fc88823a497", null ],
    [ "Gateway", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetTK302EthernetConfigurationResponse.html#ac6ac4be92f4e72f805c8041f9af5c84f", null ],
    [ "IPAddress", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetTK302EthernetConfigurationResponse.html#aee72c87e60a1422cd9f8f5b29f921cde", null ],
    [ "MACAddress", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetTK302EthernetConfigurationResponse.html#a54e51cc28bbb2e23bc74da93a3086656", null ],
    [ "NetMask", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetTK302EthernetConfigurationResponse.html#a7535515b7f11143fbc5bdf0fba17036d", null ],
    [ "Port", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetTK302EthernetConfigurationResponse.html#a66455ef35e485caefc70bbd91c084c0f", null ],
    [ "printerName", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetTK302EthernetConfigurationResponse.html#accfec6d5af1acae4a29b7c46da910622", null ]
];