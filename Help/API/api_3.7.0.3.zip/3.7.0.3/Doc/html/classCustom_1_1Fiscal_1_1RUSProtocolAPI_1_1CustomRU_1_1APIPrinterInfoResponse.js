var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIPrinterInfoResponse =
[
    [ "APIPrinterInfoResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIPrinterInfoResponse.html#aa9706a8575adc554bb91e3f2210b941d", null ],
    [ "APIPrinterInfoResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIPrinterInfoResponse.html#adb5abd0848718021b7bceff9285bb2b6", null ],
    [ "ActualFM", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIPrinterInfoResponse.html#a472fd9a18c2c2db91ad00e2593aeceba", null ],
    [ "CutCounter", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIPrinterInfoResponse.html#ad61992652e2f32e3401d92b611b821a8", null ],
    [ "ECRVersion", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIPrinterInfoResponse.html#a74c638425ea742ca9c1a596d038ab8c1", null ],
    [ "IconCount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIPrinterInfoResponse.html#a5e9c09058cf0389870149f3c27bf5390", null ],
    [ "IconHeigthMaxValue", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIPrinterInfoResponse.html#a414b1acf3b74ae91dabb078284a32df7", null ],
    [ "IconKbMaxValue", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIPrinterInfoResponse.html#a553f4d2101a42dfd53982e069fd2a8d3", null ],
    [ "IconWidthMaxValue", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIPrinterInfoResponse.html#aa302dbb6352d3c7c6979559ed88ddf43", null ],
    [ "Model", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIPrinterInfoResponse.html#ab13d92d6b9d3cdf6805aef04ff8edd96", null ],
    [ "PowerOnCounter", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIPrinterInfoResponse.html#a84d5887262481bb1fd0d05e70a3c1168", null ],
    [ "PrintedPapaer", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIPrinterInfoResponse.html#a88ccde62c85cfc03a98f8bb85b1361da", null ],
    [ "PrinterDot", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIPrinterInfoResponse.html#a0112ceb6c127d2052a743b650cd30560", null ],
    [ "RegistrationProtocolVersion", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIPrinterInfoResponse.html#a2dfde7517bcdacb60b81cacf68d5ed61", null ],
    [ "SerialNumber", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIPrinterInfoResponse.html#a76f3383b6fc4dfd225344661bf59d6de", null ],
    [ "State", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIPrinterInfoResponse.html#a0a5775b6fe044b46abefd01bbd466d8b", null ],
    [ "Version", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIPrinterInfoResponse.html#a13d87bb04b2158706e889a236e10ce90", null ],
    [ "VersionMD5", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIPrinterInfoResponse.html#a264655b5a05c2d7cb866b02fedd7494e", null ]
];