var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetOFDConfigurationResponse =
[
    [ "APIGetOFDConfigurationResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetOFDConfigurationResponse.html#ae06ef685896133748dfdd6dc5a8b3465", null ],
    [ "APIGetOFDConfigurationResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetOFDConfigurationResponse.html#a4ba91a2c76b43ad4c792f9f46881bc85", null ],
    [ "FDOChannel", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetOFDConfigurationResponse.html#a286baebbb92ec35b016614d61d48bf77", null ],
    [ "FDOWebSitePort", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetOFDConfigurationResponse.html#a151f3d9e74f1f62c2c2ca88c90f7c2fa", null ],
    [ "FDOWebSiteUrl", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetOFDConfigurationResponse.html#a39585e18c557462305dfa975a6db1a6d", null ],
    [ "newDocSubcause1", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetOFDConfigurationResponse.html#a0555d4f1a48371a1b81feb51c3af8206", null ],
    [ "newDocSubcause2", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetOFDConfigurationResponse.html#a721d41d1aaf11c1f94fa5fa7a7d79257", null ],
    [ "newDocSubcause3", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetOFDConfigurationResponse.html#a34fdef19de0e16140cb4dc67b8f3c8b0", null ],
    [ "newDocSubcause4", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetOFDConfigurationResponse.html#a1f403f0149047a26e9cf65420634c5ff", null ],
    [ "newDocSubcause5", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetOFDConfigurationResponse.html#a9a344d273879230a0e2a658578da756d", null ],
    [ "newDocSubcause6", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetOFDConfigurationResponse.html#a3f2d97469fb4b0b11d568b4f984ebf67", null ],
    [ "newDocSubcauseOther", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetOFDConfigurationResponse.html#a7cf85417832250b985332ac768d4601a", null ],
    [ "OFDBitConfiguration", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetOFDConfigurationResponse.html#aaf7bbaac0d3537e2cacd9ba7b093d52d", null ],
    [ "PrintReport", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetOFDConfigurationResponse.html#aa1c33759ecc794755e96d5496753f061", null ],
    [ "TimerACK", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetOFDConfigurationResponse.html#a9643fc5403f086c1fcf64ee135d615ef", null ],
    [ "TimerC", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetOFDConfigurationResponse.html#a7fd456dd7d71901345da2b9cb4c22ed3", null ],
    [ "TimerFN", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetOFDConfigurationResponse.html#a3282086030f7cf1e872a2b35b131e12d", null ],
    [ "TxIfAnyTimer", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetOFDConfigurationResponse.html#a3635dec057c43b40227a448c5a887476", null ],
    [ "TxOnDayClose", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIGetOFDConfigurationResponse.html#a8b074bf0c32d6519e9ee92cfd2796d33", null ]
];