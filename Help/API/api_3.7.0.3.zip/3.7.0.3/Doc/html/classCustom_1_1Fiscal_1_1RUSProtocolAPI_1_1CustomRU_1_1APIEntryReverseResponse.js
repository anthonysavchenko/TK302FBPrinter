var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIEntryReverseResponse =
[
    [ "APIEntryReverseResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIEntryReverseResponse.html#afd74333bbe7f57c67ae5f6b210b35615", null ],
    [ "APIEntryReverseResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIEntryReverseResponse.html#a4d357e2d3e2af83d55f4850d81d0445d", null ],
    [ "DocumentNumber", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIEntryReverseResponse.html#aeba26c295d547a583d5669762108bf11", null ],
    [ "SessionNumber", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIEntryReverseResponse.html#a30d194534cc62fd6d43a082d97f12e60", null ],
    [ "SubtotalAmount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIEntryReverseResponse.html#a3bca8ce9458a3ee74a6ad285c768f397", null ]
];