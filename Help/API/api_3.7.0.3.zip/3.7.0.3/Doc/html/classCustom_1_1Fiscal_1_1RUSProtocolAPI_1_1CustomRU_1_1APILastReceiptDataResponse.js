var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APILastReceiptDataResponse =
[
    [ "APILastReceiptDataResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APILastReceiptDataResponse.html#a7f8c698f7668000803d06774eddf165c", null ],
    [ "APILastReceiptDataResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APILastReceiptDataResponse.html#a82c75853a711c045d76e656b64fe11ea", null ],
    [ "Date", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APILastReceiptDataResponse.html#a97f8c23421554102eb2fc192138309ce", null ],
    [ "DocumentAmount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APILastReceiptDataResponse.html#a72511b20d015dc5ac49ecf03af50f710", null ],
    [ "DocumentNumber", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APILastReceiptDataResponse.html#a85e5bee23bc144e977f3688ee7853d4e", null ]
];