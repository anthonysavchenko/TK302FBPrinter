var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APINotTrasmittedCounterStatusResponse =
[
    [ "APINotTrasmittedCounterStatusResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APINotTrasmittedCounterStatusResponse.html#a935a9039714cedd77cb5cb8a28a2b2c9", null ],
    [ "APINotTrasmittedCounterStatusResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APINotTrasmittedCounterStatusResponse.html#ac54c162fa57ecdfd0908a8e3aa8394fa", null ],
    [ "NotTrasmittedCount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APINotTrasmittedCounterStatusResponse.html#a092481acd43c0e0bf5eb57a583d3b9a3", null ],
    [ "PurchaseAmount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APINotTrasmittedCounterStatusResponse.html#adac48deac4c16645f3813c731f6ed12d", null ],
    [ "PurchaseReturnAmount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APINotTrasmittedCounterStatusResponse.html#a7bb92e332981fc30b947dac9c43c43e1", null ],
    [ "PurchaseReturnTicketCount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APINotTrasmittedCounterStatusResponse.html#ac21b69fc9b77322bd22d5b149df16ecf", null ],
    [ "PurchaseTicketCount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APINotTrasmittedCounterStatusResponse.html#a2521f14927668789336f0b673aecfafb", null ],
    [ "SaleAmount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APINotTrasmittedCounterStatusResponse.html#ae665ccc3d9063e8799b9251daedd92e5", null ],
    [ "SaleReturnAmount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APINotTrasmittedCounterStatusResponse.html#a7c905a00c4764db9fd8e1207664cee8d", null ],
    [ "SaleReturnTicketCount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APINotTrasmittedCounterStatusResponse.html#a50603feae59a3eea875a7d25c13b900b", null ],
    [ "SaleTicketCount", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APINotTrasmittedCounterStatusResponse.html#a80348b3be51da10018997314326fd943", null ]
];