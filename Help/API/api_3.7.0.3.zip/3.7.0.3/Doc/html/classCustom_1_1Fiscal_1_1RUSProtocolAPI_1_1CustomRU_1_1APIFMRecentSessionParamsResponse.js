var classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIFMRecentSessionParamsResponse =
[
    [ "APIFMRecentSessionParamsResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIFMRecentSessionParamsResponse.html#a94b8dc50a4b7ba452a73bc31250438ab", null ],
    [ "APIFMRecentSessionParamsResponse", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIFMRecentSessionParamsResponse.html#a4f33ec748e9294d64cead74d9c11fb24", null ],
    [ "FMFDNumber", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIFMRecentSessionParamsResponse.html#a6c35dc10daf82f1f419e7e11362d700f", null ],
    [ "FMSessionNumber", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIFMRecentSessionParamsResponse.html#aab2f224b3d4bd2087629e424cb28c391", null ],
    [ "FMSessionState", "classCustom_1_1Fiscal_1_1RUSProtocolAPI_1_1CustomRU_1_1APIFMRecentSessionParamsResponse.html#a24c0a3d3c59b5e965630617dbf46f45f", null ]
];