﻿
namespace Q3X_F
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonConnect = new System.Windows.Forms.Button();
            this.comboBoxCOM = new System.Windows.Forms.ComboBox();
            this.buttonDisconnect = new System.Windows.Forms.Button();
            this.buttonDayOpen = new System.Windows.Forms.Button();
            this.buttonDayClose = new System.Windows.Forms.Button();
            this.buttonOpenTck = new System.Windows.Forms.Button();
            this.buttonSale = new System.Windows.Forms.Button();
            this.buttonCloseTck = new System.Windows.Forms.Button();
            this.buttonBeep = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonConnect
            // 
            this.buttonConnect.Location = new System.Drawing.Point(180, 12);
            this.buttonConnect.Name = "buttonConnect";
            this.buttonConnect.Size = new System.Drawing.Size(117, 24);
            this.buttonConnect.TabIndex = 0;
            this.buttonConnect.Text = "Connect";
            this.buttonConnect.UseVisualStyleBackColor = true;
            this.buttonConnect.Click += new System.EventHandler(this.buttonConnect_Click);
            // 
            // comboBoxCOM
            // 
            this.comboBoxCOM.FormattingEnabled = true;
            this.comboBoxCOM.Location = new System.Drawing.Point(13, 13);
            this.comboBoxCOM.Name = "comboBoxCOM";
            this.comboBoxCOM.Size = new System.Drawing.Size(161, 23);
            this.comboBoxCOM.TabIndex = 1;
            // 
            // buttonDisconnect
            // 
            this.buttonDisconnect.Location = new System.Drawing.Point(303, 12);
            this.buttonDisconnect.Name = "buttonDisconnect";
            this.buttonDisconnect.Size = new System.Drawing.Size(122, 24);
            this.buttonDisconnect.TabIndex = 2;
            this.buttonDisconnect.Text = "Disconnect";
            this.buttonDisconnect.UseVisualStyleBackColor = true;
            this.buttonDisconnect.Click += new System.EventHandler(this.buttonDisconnect_Click);
            // 
            // buttonDayOpen
            // 
            this.buttonDayOpen.Location = new System.Drawing.Point(12, 105);
            this.buttonDayOpen.Name = "buttonDayOpen";
            this.buttonDayOpen.Size = new System.Drawing.Size(161, 23);
            this.buttonDayOpen.TabIndex = 3;
            this.buttonDayOpen.Text = "Day Open";
            this.buttonDayOpen.UseVisualStyleBackColor = true;
            this.buttonDayOpen.Click += new System.EventHandler(this.buttonDayOpen_Click);
            // 
            // buttonDayClose
            // 
            this.buttonDayClose.Location = new System.Drawing.Point(212, 105);
            this.buttonDayClose.Name = "buttonDayClose";
            this.buttonDayClose.Size = new System.Drawing.Size(161, 23);
            this.buttonDayClose.TabIndex = 4;
            this.buttonDayClose.Text = "Day Close";
            this.buttonDayClose.UseVisualStyleBackColor = true;
            this.buttonDayClose.Click += new System.EventHandler(this.buttonDayClose_Click);
            // 
            // buttonOpenTck
            // 
            this.buttonOpenTck.Location = new System.Drawing.Point(12, 152);
            this.buttonOpenTck.Name = "buttonOpenTck";
            this.buttonOpenTck.Size = new System.Drawing.Size(161, 34);
            this.buttonOpenTck.TabIndex = 5;
            this.buttonOpenTck.Text = "Open Tck (sample)";
            this.buttonOpenTck.UseVisualStyleBackColor = true;
            this.buttonOpenTck.Click += new System.EventHandler(this.buttonOpenTck_Click);
            // 
            // buttonSale
            // 
            this.buttonSale.Location = new System.Drawing.Point(12, 204);
            this.buttonSale.Name = "buttonSale";
            this.buttonSale.Size = new System.Drawing.Size(161, 33);
            this.buttonSale.TabIndex = 6;
            this.buttonSale.Text = "Sale (sample)";
            this.buttonSale.UseVisualStyleBackColor = true;
            this.buttonSale.Click += new System.EventHandler(this.buttonSale_Click);
            // 
            // buttonCloseTck
            // 
            this.buttonCloseTck.Location = new System.Drawing.Point(12, 259);
            this.buttonCloseTck.Name = "buttonCloseTck";
            this.buttonCloseTck.Size = new System.Drawing.Size(161, 33);
            this.buttonCloseTck.TabIndex = 7;
            this.buttonCloseTck.Text = "Close Tck (sample)";
            this.buttonCloseTck.UseVisualStyleBackColor = true;
            this.buttonCloseTck.Click += new System.EventHandler(this.buttonCloseTck_Click);
            // 
            // buttonBeep
            // 
            this.buttonBeep.Location = new System.Drawing.Point(13, 57);
            this.buttonBeep.Name = "buttonBeep";
            this.buttonBeep.Size = new System.Drawing.Size(161, 23);
            this.buttonBeep.TabIndex = 8;
            this.buttonBeep.Text = "Beep";
            this.buttonBeep.UseVisualStyleBackColor = true;
            this.buttonBeep.Click += new System.EventHandler(this.buttonBeep_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonBeep);
            this.Controls.Add(this.buttonCloseTck);
            this.Controls.Add(this.buttonSale);
            this.Controls.Add(this.buttonOpenTck);
            this.Controls.Add(this.buttonDayClose);
            this.Controls.Add(this.buttonDayOpen);
            this.Controls.Add(this.buttonDisconnect);
            this.Controls.Add(this.comboBoxCOM);
            this.Controls.Add(this.buttonConnect);
            this.Name = "Form1";
            this.Text = "Q3X-F";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonConnect;
        private System.Windows.Forms.ComboBox comboBoxCOM;
        private System.Windows.Forms.Button buttonDisconnect;
        private System.Windows.Forms.Button buttonDayOpen;
        private System.Windows.Forms.Button buttonDayClose;
        private System.Windows.Forms.Button buttonOpenTck;
        private System.Windows.Forms.Button buttonSale;
        private System.Windows.Forms.Button buttonCloseTck;
        private System.Windows.Forms.Button buttonBeep;
    }
}

