﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using Custom.Fiscal.RUSProtocolAPI;
using Custom.Fiscal.RUSProtocolAPI.Comunication;
using Custom.Fiscal.RUSProtocolAPI.Enums;
using Custom.Fiscal.RUSProtocolAPI.CustomRU;



namespace Q3X_F
{
    public partial class Form1 : Form
    {

        //Default Settings
        private string OperatorPassword = "999999";

        private static ProtocolAPI printerAPI = new ProtocolAPI();
        private SerialPortParams rs232Params = null;

        public Form1()
        {
            InitializeComponent();
            this.Load += new EventHandler(Form1_Load);
        }

        void Form1_Load(object sender, EventArgs e)
        {
            SetPortNameValues(this.comboBoxCOM);
        }

        private void SetPortNameValues(object obj)
        {
            foreach (string str in SerialPort.GetPortNames())
            {
                ((ComboBox)obj).Items.Add(str);
            }
            if (((ComboBox)obj).Items.Count > 0)
                ((ComboBox)obj).SelectedIndex = 0;

        }

        private void buttonConnect_Click(object sender, EventArgs e)
        {
            printerAPI.ComunicationType = Custom.Fiscal.RUSProtocolAPI.Enums.ComunicationTypeEnum.RS232;

            rs232Params = new SerialPortParams()
            {
                BaudRate = 57600,
                DataBits = 8,
                HandshakeProp = System.IO.Ports.Handshake.None,
                Parity = System.IO.Ports.Parity.None,
                PortName = this.comboBoxCOM.Text,
                StopBits = System.IO.Ports.StopBits.One,
                Dtr = false,
                Rts = false
            };

            printerAPI.ComunicationParams = new object[]{ rs232Params.BaudRate,
                                                              rs232Params.DataBits,
                                                              rs232Params.HandshakeProp,
                                                              rs232Params.Parity,
                                                              rs232Params.PortName,
                                                              rs232Params.StopBits,
                                                              rs232Params.Dtr,
                                                              rs232Params.Rts };

            var cmdResponse = printerAPI.OpenConnection();

        }

        private void buttonBeep_Click(object sender, EventArgs e)
        {
            APIBaseResponse cmdResponse = printerAPI.Beep(OperatorPassword);
        }

        private void buttonDisconnect_Click(object sender, EventArgs e)
        {
            var cmdResponse = printerAPI.CloseConnection();
        }

        private void buttonDayOpen_Click(object sender, EventArgs e)
        {
            bool print = true;                              // печатаь ФД
            bool saveOnFile = false;							// не сохранять ФД в памяти ККТ (формат документа .spl)
            APIOpenFiscalDayResponse cmdResponse = printerAPI.OpenFiscalDay(OperatorPassword, print, saveOnFile);
        }

        private void buttonDayClose_Click(object sender, EventArgs e)
        {
            bool print = true;                              // печатаь ФД
            bool saveOnFile = false;							// не сохранять ФД в памяти ККТ (формат документа .spl)
            APIZReportResponse cmdResponse = printerAPI.ZReport(OperatorPassword, print, saveOnFile);
        }

        private void buttonOpenTck_Click(object sender, EventArgs e)
        {
            bool print = true;                              // печатаь ФД
            bool saveOnFile = false;							// не сохранять ФД в памяти ККТ (формат документа .spl)
            var docType = ReceiptItemTypeEnum.Sale;		// тип докмента - Приход
            var taxType = TaxCodeEnum.Traditional;		// тип СНО - Общая

            APIBaseResponse cmdResponse = printerAPI.OpenFiscalDocument(OperatorPassword, print, saveOnFile, (ReceiptTypeEnum)docType, taxType);
        }

        private void buttonSale_Click(object sender, EventArgs e)
        {
            var itemType = ReceiptItemTypeEnum.Sale; 			        // признак предмета расчета - Приход
            var paymentWayType = PaymentWayEnum.CompletePayment;	    // полный расчет
            var paymentSubjType = PaymentSubjectEnum.GoodsForSelling;   // товар

            bool hasDiscountAddon = false;                              // Наличие скидки/Наценки №1
            bool hasPaymentSubj = false;                                // нет тега #1191 - Дополнительный реквизит предмета продажи
            bool hasGoodsAssortment = false;                            // нет тега #1162 - Код маркировки (для ФФД 1.05, 1.1)
            bool hasNumberCustomsDeclaration = false;				    // Наличие кода таможенной декларации (#1231)
            bool excludeModifier = false;								// исключить позицию из скидки на подытог (не применять к этой позиции скидку, при подсчете подытога)
            string codeCountryProducer = "000";                         // код страны производителя

            long quantity = 1000;                                       // количество
            long amount = 22000;                                        // стоимость за единицу
            long excise = 0;                                            // акциз
            int deptNumber = 4;                                         // отдел(НДС)
            int discountAddonType1 = 0;                                 // тип скидки Наценки 0 - скидка, 1 - наценка    
            int discountAddonType2 = 0;                                 // тип скидки Наценки 0 - сумма, 1 - процент  
            int discountAddonAmount = 0;                                // сумма(%) скидки Наценки №1    

            string text = "Товар для продажи №1";                       // наименование предмета продажи
            
            string paymentSubjectText = "";

            var goodsType = CodeOfGoodsEnum.tobacco;                    // тип кода маркировки. игнорируестя, если hasGoodsAssortment = false
            var goodsAssortmentGTIN = "";                               // GTIN кода маркировки. игнорируестя, если hasGoodsAssortment = false
            var goodsAssortmentSerial = "";                             // Серийный номер кода маркировки. игнорируестя, если hasGoodsAssortment = false
            var numberCustomsDeclarationText = "";                      // Номер дакларации. игнорируестя, если hasGoodsAssortment = false

            bool hasDiscountAddon2 = false;                             // Наличие скидки/Наценки №2
            var discountAddonType3 = 0;                                 // тип скидки Наценки №2: 0 - скидка, 1 - наценка    
            var discountAddonType4 = 0;                                 // тип скидки Наценки №2: 0 - сумма, 1 - процент  
            var discountAddonAmount2 = 0;                               // сумма(%) скидки Наценки №2    

            APIBaseResponse cmdResponse = printerAPI.PrintRecItem(OperatorPassword,
                                                                            itemType,
                                                                            hasDiscountAddon,
                                                                            hasPaymentSubj,
                                                                            hasGoodsAssortment,
                                                                            hasNumberCustomsDeclaration,
                                                                            excludeModifier,
                                                                            paymentWayType,
                                                                            paymentSubjType,
                                                                            codeCountryProducer,
                                                                            quantity,
                                                                            amount,
                                                                            excise,
                                                                            deptNumber,
                                                                            discountAddonType1,
                                                                            discountAddonType2,
                                                                            discountAddonAmount,
                                                                            text,
                                                                            paymentSubjectText,
                                                                            goodsType,
                                                                            goodsAssortmentGTIN,
                                                                            goodsAssortmentSerial,
                                                                            numberCustomsDeclarationText,
                                                                            hasDiscountAddon2,
                                                                            discountAddonType3,
                                                                            discountAddonType4,
                                                                            discountAddonAmount2
                                                                            );
        }

        private void buttonCloseTck_Click(object sender, EventArgs e)
        {
            long cash = 22000;                      // наличными
            long cashless = 0;                      // безналичными
            long advance = 0;                       // аванс
            long credit = 0;                        // кредит
            long otherPayment = 0;                  // другие типы оплаты
            var hasAdditionalPropertyCheck = false; // Наличие Дополнительного реквизита чека (#1192)
            var additionalPropertyCheckText = "";   // значение Дополнительного реквизита чека (#1192)
            var hasFieldReceiver = false;           // Наличие реквизита "Получатель/Покупатель (#1227)
            var receiver = "";                      // значение #1227
            var hasFieldReceiverInn = false;        // Наличие ИНН Покупателя (#1228)
            var receiverInn = "";                   // значение #1228
            var subtotalRounding = false;           // округление подытога до целых рублей

            APICheckClosingResponse cmdResponse = printerAPI.CheckClosing(OperatorPassword,
                                                                            cash,
                                                                            cashless,
                                                                            advance,
                                                                            credit,
                                                                            otherPayment,
                                                                            hasAdditionalPropertyCheck,
                                                                            additionalPropertyCheckText,
                                                                            hasFieldReceiver,
                                                                            receiver,
                                                                            hasFieldReceiverInn,
                                                                            receiverInn,
                                                                            subtotalRounding);
        }
    }
}
