﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using Custom.Fiscal.RUSProtocolAPI;
using Custom.Fiscal.RUSProtocolAPI.Comunication;
using Custom.Fiscal.RUSProtocolAPI.Enums;
using Custom.Fiscal.RUSProtocolAPI.CustomRU;



namespace Q3X_F
{
    public partial class Form1 : Form
    {

        //Default Settings
        private string OperatorPassword = "999999";

        private static ProtocolAPI printerAPI = new ProtocolAPI();
        private SerialPortParams rs232Params = null;

        public Form1()
        {
            InitializeComponent();
            this.Load += new EventHandler(Form1_Load);
        }

        void Form1_Load(object sender, EventArgs e)
        {
            SetPortNameValues(this.comboBoxCOM);
        }

        private void SetPortNameValues(object obj)
        {
            foreach (string str in SerialPort.GetPortNames())
            {
                ((ComboBox)obj).Items.Add(str);
            }
            if (((ComboBox)obj).Items.Count > 0)
                ((ComboBox)obj).SelectedIndex = 0;

        }

        private void buttonConnect_Click(object sender, EventArgs e)
        {
            printerAPI.ComunicationType = Custom.Fiscal.RUSProtocolAPI.Enums.ComunicationTypeEnum.RS232;

            rs232Params = new SerialPortParams()
            {
                BaudRate = 57600,
                DataBits = 8,
                HandshakeProp = System.IO.Ports.Handshake.None,
                Parity = System.IO.Ports.Parity.None,
                PortName = this.comboBoxCOM.Text,
                StopBits = System.IO.Ports.StopBits.One,
                Dtr = false,
                Rts = false
            };

            printerAPI.ComunicationParams = new object[]{ rs232Params.BaudRate,
                                                              rs232Params.DataBits,
                                                              rs232Params.HandshakeProp,
                                                              rs232Params.Parity,
                                                              rs232Params.PortName,
                                                              rs232Params.StopBits,
                                                              rs232Params.Dtr,
                                                              rs232Params.Rts };

            var cmdResponse = printerAPI.OpenConnection();

        }

        private void buttonBeep_Click(object sender, EventArgs e)
        {
            APIBaseResponse cmdResponse = printerAPI.Beep(OperatorPassword);
        }

        private void buttonDisconnect_Click(object sender, EventArgs e)
        {
            var cmdResponse = printerAPI.CloseConnection();
        }

        private void buttonDayOpen_Click(object sender, EventArgs e)
        {
            bool print = true;                              // печатаь ФД
            bool saveOnFile = false;							// не сохранять ФД в памяти ККТ (формат документа .spl)
            APIOpenFiscalDayResponse cmdResponse = printerAPI.OpenFiscalDay(OperatorPassword, print, saveOnFile);
        }

        private void buttonDayClose_Click(object sender, EventArgs e)
        {
            bool print = true;                              // печатаь ФД
            bool saveOnFile = false;							// не сохранять ФД в памяти ККТ (формат документа .spl)
            APIZReportResponse cmdResponse = printerAPI.ZReport(OperatorPassword, print, saveOnFile);
        }

        private void buttonOpenTck_Click(object sender, EventArgs e)
        {
            bool print = true;                              // печатаь ФД
            bool saveOnFile = false;							// не сохранять ФД в памяти ККТ (формат документа .spl)
            var docType = ReceiptItemTypeEnum.Sale;		// тип докмента - Приход
            var taxType = TaxCodeEnum.Traditional;		// тип СНО - Общая

            APIBaseResponse cmdResponse = printerAPI.OpenFiscalDocument(OperatorPassword, print, saveOnFile, (ReceiptTypeEnum)docType, taxType);
        }

        private void buttonSale_Click(object sender, EventArgs e)
        {
            var itemType = ReceiptItemTypeEnum.Sale; 			        // признак предмета расчета - Приход
            var paymentWayType = PaymentWayEnum.CompletePayment;	    // полный расчет
            var paymentSubjType = PaymentSubjectEnum.GoodsForSelling;   // товар

            bool hasDiscountAddon = false;                              // Наличие скидки/Наценки №1
            bool hasPaymentSubj = false;                                // нет тега #1191 - Дополнительный реквизит предмета продажи
            bool hasGoodsAssortment = false;                            // нет тега #1162 - Код маркировки (для ФФД 1.05, 1.1)
            bool hasNumberCustomsDeclaration = false;				    // Наличие кода таможенной декларации (#1231)
            bool excludeModifier = false;								// исключить позицию из скидки на подытог (не применять к этой позиции скидку, при подсчете подытога)
            string codeCountryProducer = "000";                         // код страны производителя

            long quantity = 1000;                                       // количество
            long amount = 22000;                                        // стоимость за единицу
            long excise = 0;                                            // акциз
            int deptNumber = 4;                                         // отдел(НДС)
            int discountAddonType1 = 0;                                 // тип скидки Наценки 0 - скидка, 1 - наценка    
            int discountAddonType2 = 0;                                 // тип скидки Наценки 0 - сумма, 1 - процент  
            int discountAddonAmount = 0;                                // сумма(%) скидки Наценки №1    

            string text = "Товар для продажи №1";                       // наименование предмета продажи
            
            string paymentSubjectText = "";

            var goodsType = CodeOfGoodsEnum.tobacco;                    // тип кода маркировки. игнорируестя, если hasGoodsAssortment = false
            var goodsAssortmentGTIN = "";                               // GTIN кода маркировки. игнорируестя, если hasGoodsAssortment = false
            var goodsAssortmentSerial = "";                             // Серийный номер кода маркировки. игнорируестя, если hasGoodsAssortment = false
            var numberCustomsDeclarationText = "";                      // Номер дакларации. игнорируестя, если hasGoodsAssortment = false

            bool hasDiscountAddon2 = false;                             // Наличие скидки/Наценки №2
            var discountAddonType3 = 0;                                 // тип скидки Наценки №2: 0 - скидка, 1 - наценка    
            var discountAddonType4 = 0;                                 // тип скидки Наценки №2: 0 - сумма, 1 - процент  
            var discountAddonAmount2 = 0;                               // сумма(%) скидки Наценки №2    

            APIBaseResponse cmdResponse = printerAPI.PrintRecItem(OperatorPassword,
                                                                            itemType,
                                                                            hasDiscountAddon,
                                                                            hasPaymentSubj,
                                                                            hasGoodsAssortment,
                                                                            hasNumberCustomsDeclaration,
                                                                            excludeModifier,
                                                                            paymentWayType,
                                                                            paymentSubjType,
                                                                            codeCountryProducer,
                                                                            quantity,
                                                                            amount,
                                                                            excise,
                                                                            deptNumber,
                                                                            discountAddonType1,
                                                                            discountAddonType2,
                                                                            discountAddonAmount,
                                                                            text,
                                                                            paymentSubjectText,
                                                                            goodsType,
                                                                            goodsAssortmentGTIN,
                                                                            goodsAssortmentSerial,
                                                                            numberCustomsDeclarationText,
                                                                            hasDiscountAddon2,
                                                                            discountAddonType3,
                                                                            discountAddonType4,
                                                                            discountAddonAmount2
                                                                            );
        }

        private void buttonCloseTck_Click(object sender, EventArgs e)
        {
            long cash = 22000;                      // наличными
            long cashless = 0;                      // безналичными
            long advance = 0;                       // аванс
            long credit = 0;                        // кредит
            long otherPayment = 0;                  // другие типы оплаты
            var hasAdditionalPropertyCheck = false; // Наличие Дополнительного реквизита чека (#1192)
            var additionalPropertyCheckText = "";   // значение Дополнительного реквизита чека (#1192)
            var hasFieldReceiver = false;           // Наличие реквизита "Получатель/Покупатель (#1227)
            var receiver = "";                      // значение #1227
            var hasFieldReceiverInn = false;        // Наличие ИНН Покупателя (#1228)
            var receiverInn = "";                   // значение #1228
            var subtotalRounding = false;           // округление подытога до целых рублей

            APICheckClosingResponse cmdResponse = printerAPI.CheckClosing(OperatorPassword,
                                                                            cash,
                                                                            cashless,
                                                                            advance,
                                                                            credit,
                                                                            otherPayment,
                                                                            hasAdditionalPropertyCheck,
                                                                            additionalPropertyCheckText,
                                                                            hasFieldReceiver,
                                                                            receiver,
                                                                            hasFieldReceiverInn,
                                                                            receiverInn,
                                                                            subtotalRounding);
        }

        private void setAgentFlag_Click(object sender, EventArgs e)
        {
            /*
            **  Параметры для SendOFDData
                DeleteALL = 0,
                MoneyTransferOperatorAddress = 1005,
                PurchaserPhonOrEmailAddress = 1008,
                MoneyTransferOperatorTIN = 1016,
                MoneyTransferOperatorName = 1026,
                PayingAgentOperation = 1044,
                FlagOfAgent = 1057,
                PayingAgentPhone = 1073,
                PaymentsReceivingOperatorPhone = 1074,
                MoneyTransferOperatorPhone = 1075,
                SupplierPhone = 1171,
                FlagOfAgentPaymentSubject = 1222,
                SupplierName = 1225,
                SupplierTIN = 1226

            ** Доступные данные агента (Протокол команд ККТ Custom):
                ID	    Имя	                                                                Формат	                        Позиция
                0	    Удалить все данные для ОФД, посланные посредством ПК                 -	                            SE, TE
                1005	Адрес оператора перевода	                                Текст {С}, 256 символов	                SE, TE
                1008	Телефонный номер или адрес эл. почты покупателя	            Текст +{Ц} или {С}@{С}, 64 символа	    TE
                1016	ИНН оператора перевода	                                    Текст 10 или 12 символов	            SE, TE
                1026	Наименование оператора перевода	                            Текст {С}, 64 символа	                SE, TE
                1044	Операция платежного агента	                                Текст {С}, 24 символа	                SE, TE
                1057	Признак агента	                                            Байт	                                TE
                1073	Телефон платежного агента	                                Текст +{Ц}, 19 символов	                SE, TE, R
                1074	Телефон оператора по приему платежей	                    Текст +{Ц}, 19 символов	                SE, TE, R
                1075	Телефон оператора перевода	                                Текст +{Ц}, 19 символов	                SE, TE, R
                1171	Телефон поставщика	                                        Текст +{Ц}, 19 символов	                SE, TE, R
                1222	Признак агента по предмету расчета	                        Байт	                                SE
                1225	Наименование поставщика	                                    Текст {С}, 256 символов	                SE
                1226	ИНН поставщика	                                            Текст 10 или 12 символов	            SE

            */

            var actionToDo = OFDDataTypeEnum.FlagOfAgentPaymentSubject;                          //#1222 - Признак Агента по предмету расчета;

            /*
                Bit Mask значения тегов #1057 / #1222 в соответствии с ФФд.
                Таблица 7
                Значения реквизита «признак агента» (тег 1057), «признак агента по предмету расчета» (тег 1222) и описание формата данных этих реквизитов в печатной форме
                Номер бита	    Основание для присвоения кода реквизиту	Формат ПФ
                0	            Оказание услуг покупателю (клиенту) пользователем, являющимся банковским платежным агентом	«БАНК. ПЛ. АГЕНТ»
                1	            Оказание услуг покупателю (клиенту) пользователем, являющимся банковским платежным субагентом	«БАНК. ПЛ. СУБАГЕНТ»
                2	            Оказание услуг покупателю (клиенту) пользователем, являющимся платежным агентом	«ПЛ. АГЕНТ»
                3	            Оказание услуг покупателю (клиенту) пользователем, являющимся платежным субагентом	«ПЛ. СУБАГЕНТ»
                4	            Осуществление расчета с покупателем (клиентом) пользователем, являющимся поверенным	«ПОВЕРЕННЫЙ»
                5	            Осуществление расчета с покупателем (клиентом) пользователем, являющимся комиссионером	«КОМИССИОНЕР»
                6	            Осуществление расчета с покупателем (клиентом) пользователем, являющимся агентом и не являющимся банковским платежным агентом (субагентом), платежным агентом (субагентом), поверенным, комиссионером	«АГЕНТ»

                Decimal        Hexidecimal    Binary
                1              0x0001         0000000000000001      
                2              0x0002         0000000000000010      
                4              0x0004         0000000000000100      
                8              0x0008         0000000000001000      
                16             0x0010         0000000000010000      
                32             0x0020         0000000000100000      
                64             0x0040         0000000001000000      
            */
            byte data = 0;

            byte b0 = 0x0001;       
            byte b1 = 0x0002;
            byte b2 = 0x0004;
            byte b3 = 0x0008;
            byte b4 = 0x0010;
            byte b5 = 0x0020;
            byte b6 = 0x0040;

            //Для АГЕНТА заполняем в #1222 бит 6
            data += b6;

            //передаем флаг агента!
            APIBaseResponse cmdResponse = printerAPI.SendOFDData(OperatorPassword, actionToDo, 1, new byte[1] { data });
        }

        private void setAgentData_Click(object sender, EventArgs e)
        {
            // «данные поставщика» #1224, включающий в себя: телефон поставщика	#1171 и наименование поставщика #1225
            var action0ToDo = OFDDataTypeEnum.SupplierPhone;                   // телефон поставщика	#1171;
            var action0TxtValue = "+7004";
            APIBaseResponse cmd0Response = printerAPI.SendOFDData(OperatorPassword, action0ToDo, action0TxtValue);

            var action1ToDo = OFDDataTypeEnum.SupplierName;                   // наименование поставщика #1225;
            var action1TxtValue = "Поставщик #1";
            APIBaseResponse cmd1Response = printerAPI.SendOFDData(OperatorPassword, action1ToDo, action1TxtValue);

            var action2ToDo = OFDDataTypeEnum.SupplierTIN;                   // ИНН_Поставщика #1226;
            var action2TxtValue = "2222222223";
            APIBaseResponse cmd2Response = printerAPI.SendOFDData(OperatorPassword, action2ToDo, action2TxtValue);

        }

        private void getAlowedOfdData_Click(object sender, EventArgs e)
        {
            // запрос возможных данных/параметров для передачи 
            APIBaseResponse cmdResponse = printerAPI.GetStatisticAllowedData(OperatorPassword);
        }
    }
}
